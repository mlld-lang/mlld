# InterpolationService

Below is a detailed design proposal for a new InterpolationService, aligned with our services-based Meld architecture, strictly following the Meld grammar & UX. It is structured and specific, showing how we isolate complexity and how directives will consume interpolation, along with a clear testing strategy that integrates smoothly into our new test setup.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I. OVERVIEW & ROLE IN THE ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The InterpolationService is responsible for expanding all variable references like:
• ${textVar}[>>(format)]  
• #{dataVar.field}[>>(format)]  
• $path, $HOMEPATH, $PROJECTPATH, and so forth.

It is purely about string transformations and variable lookups:  
• Every snippet (“${myText} is here” or “`some ${myVar} stuff`”) that references Meld variables is replaced with actual values.  
• The InterpolationService never writes to disk or manipulates the AST (that is the job of FileSystemService or ParserService).  
• It’s invoked by directive handlers whenever they need raw directive arguments to be fully expanded.

ASCII Context Diagram:

        ┌─────────────────────────┐
        │   Some Directive        │
        │  e.g. @text or @import  │
        └──────────────┬──────────┘
                       │ calls:
                       ▼
            ┌──────────────────────────────┐
            │ InterpolationService         │
            │  - parse expansions          │
            │  - unroll references         │
            │  - apply optional format     │
            └──────────────┬───────────────┘
                           │  queries:
                           ▼
        ┌──────────────────────────────┐
        │ StateService (for text/data) │
        │ PathService  (for path vars) │
        └──────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
II. USE CASE EXAMPLES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• A directive has something like:
   @text greeting = "Hello, ${userName}!"
  The TextDirectiveHandler calls interpolationService.resolveString('Hello, ${userName}!'):
    → sees ${userName}
    → calls stateService.getTextVar('userName') → e.g. "Alice"
    → final result: "Hello, Alice!"

• Another directive has:
   @run [cp ${sourceFile} /dest/${targetFile}]
  The RunDirectiveHandler calls interpolationService.resolveString('cp ${sourceFile} /dest/${targetFile}'):
    → expands the ${} references from text vars
    → final command might be "cp app.js /dest/final.js"

• Data variables (#{config.field}) get stringified if they are objects:
   "Api call to #{config.apiUrl}"
   If config.apiUrl == "http://example.com", that becomes "Api call to http://example.com"

• If a variable is not found, grammar says we produce empty string for missing data fields and environment variables. For missing text variables, we can decide to produce empty or throw, but the grammar states “missing data fields return empty string.” Typically we keep consistent across text/data for this version.

• Single optional format:
   ${textVar>>(uppercase)} → we can define a small format system where “uppercase” means toUpperCase, or we might pass the “uppercase” token to a future FormatService. The InterpolationService just calls formatService.apply("uppercase", originalValue).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
III. CODE STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Recommended directory layout (matching our new architecture):

services/
 ├─ InterpolationService/
 │   ├─ InterpolationService.ts
 │   ├─ InterpolationService.test.ts
 │   └─ README.md (optional short doc)
 └─ (other services)...

Inside InterpolationService.ts, we might define an InterpolationService class:

┌─────────────────────────────────────────────────────────────────────┐
│ export class InterpolationService {                               │
│   constructor(                                                    │
│     private stateService: StateService,                           │
│     private pathService: PathService,                             │
│     private formatService: FormatService,  // optional, if needed │
│   ) {}                                                            │
│                                                                   │
│   public resolveString(original: string, context: InterpContext): │
│     string {                                                      │
│     // Implementation logic, see section “Solution Outline”        │
│   }                                                               │
│ }                                                                 │
└─────────────────────────────────────────────────────────────────────┘

We’ll also define:

• InterpContext: “text”, “data”, “pathCommand”, “commandArgs”, etc. — so if the directive says “this string is used in a path directive,” we might do slightly different expansions or validation (like path variables can’t have field access or >> format).

Note:
Some teams prefer separate methods for “resolveInTextContext()” vs “resolveInPathContext()” to keep logic simpler. That’s optional.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IV. THE CORE ALGORITHM & ISOLATION OF COMPLEXITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

(1) Identify all expansions. We can detect them via Regex or a small token scanner.

   Possible expansions from Meld grammar:
   • ${textVar} or ${textVar>>(format)}
   • #{dataVar.field} or #{dataVar.field>>(format)}
   • $myPathVar or $HOMEPATH, etc. (in path contexts)
   • (No nested expansions like ${text${inner}})

(2) For each expansion, parse out these components:
   A) “variable type”: text (${}), data (#{}) or path ($).
   B) “variable name”: e.g. userName or config.nested
   C) optional format operator. E.g. uppercase, leftPad, etc.

(3) Look up the variable:
   If text: stateService.getTextVar(name)
   If data:  stateService.getDataVar(name), handle .field expansions
   If path:  if it's $HOMEPATH or $PROJECTPATH or any $somePath → call pathService or stateService.getPathVar(name).

(4) If not found and grammar says “missing => empty,” return "" (or log a warning).
(5) If found but it’s an object (for data var), we do JSON.stringify or partial expansions. The grammar states: “Objects and arrays get converted to JSON string representation.”
(6) If format operator is present, pass the expanded result to the FormatService. E.g. formatService.apply(formatName, stringValue).
(7) Replace the original token in the string with final expansion.

(8) Return the final string.

Complexity is isolated:
• We do not do any AST rewriting. We’re just returning a string with expansions replaced.  
• We do not do file IO or path normalization ourselves; that’s for PathService or FileSystemService.  
• The InterpolationService is purely “give me a string with ${stuff}, I’ll do lookups + expansions.”

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
V. EXAMPLE USAGE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Imagine the PathDirectiveHandler:

--------------------------------------------------------------------------------
// Pseudocode:
execute(node: DirectiveNode): void {
  // directive might have: { name: "myPath", value: "$PROJECTPATH/src/${subDir}" }
  const rawValue = node.directive.value;  // e.g. '$PROJECTPATH/src/${subDir}'
  const expandedPath = interpolationService.resolveString(rawValue, "path");

  // Then we do final path checks with pathService
  const normalized = pathService.resolve(expandedPath); 
  stateService.setPathVar(node.directive.name, normalized);
}
--------------------------------------------------------------------------------

Or the TextDirectiveHandler:

--------------------------------------------------------------------------------
execute(node: DirectiveNode): void {
  const rawValue = node.directive.value; // e.g. 'Hello, ${userName}'
  const finalValue = interpolationService.resolveString(rawValue, "text");
  stateService.setTextVar(node.directive.name, finalValue);
}
--------------------------------------------------------------------------------

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VI. TESTING STRATEGY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

We use our new test setup with a TestContext + MemfsTestFileSystem or similar. Since InterpolationService does not strictly need disk IO, we can do pure unit tests that rely on a mock StateService & mock PathService:

1. In /tests/unit/InterpolationService.test.ts:

--------------------------------------------------------------------------------
import { describe, it, expect, beforeEach } from 'vitest';
import { InterpolationService } from '../../../services/InterpolationService/InterpolationService';

describe('InterpolationService (unit)', () => {
  let interpolationService: InterpolationService;
  let mockStateService: any;
  let mockPathService: any;

  beforeEach(() => {
    mockStateService = {
      getTextVar: vi.fn(),
      getDataVar: vi.fn(),
      getPathVar: vi.fn(),
    };
    mockPathService = {
      resolve: vi.fn(),
    };

    interpolationService = new InterpolationService(
      mockStateService,
      mockPathService,
      null // if we have a separate FormatService
    );
  });

  it('expands simple ${textVar}', () => {
    mockStateService.getTextVar.mockReturnValueOnce('Alice');
    const input = 'Hello, ${userName}!';
    const output = interpolationService.resolveString(input, 'text');
    expect(output).toBe('Hello, Alice!');
    expect(mockStateService.getTextVar).toHaveBeenCalledWith('userName');
  });

  it('expands data var #{config.val}', () => {
    mockStateService.getDataVar.mockReturnValueOnce({ val: 123 });
    const input = 'Number: #{config.val}';
    const output = interpolationService.resolveString(input, 'text');
    // data var with field .val is 123 => "Number: 123"
    expect(output).toBe('Number: 123');
  });

  it('expands path var $PROJECTPATH', () => {
    // Possibly we group path expansions in "path" context
    mockPathService.resolve.mockReturnValueOnce('/my/project');
    const input = '$PROJECTPATH/app.js';
    const output = interpolationService.resolveString(input, 'path');
    // Then we see if we do `mockPathService.resolve('/my/project/app.js')`
    // or if we rely on the directive calls. This is design choice.
  });

  it('handles missing text var => empty string', () => {
    mockStateService.getTextVar.mockReturnValueOnce(undefined);
    const output = interpolationService.resolveString('Hello ${missing} world', 'text');
    expect(output).toBe('Hello  world'); // missing => empty
  });

  it('applies single format e.g. ${var>>(uppercase)}', () => {
    // If we have a formatService
    // ...
  });

  // etc. with edge cases, invalid syntax, etc.
});
--------------------------------------------------------------------------------

2. For integration tests that involve actual parse + interpret, we leverage a real StateService and real PathService, but possibly still a mock or in-memory file system. Then we do:

--------------------------------------------------------------------------------
import { describe, it, expect } from 'vitest';
import { TestContext } from '../../utils/TestContext';
import { runMeld } from '../../../sdk';

describe('InterpolationService (integration via runMeld)', () => {
  it('expands variables in an actual meld doc', async () => {
    const context = new TestContext();
    context.initialize();

    await context.builder.create({
      files: {
        'project/main.meld': `
        @text userName = "Alice" 
        @text greeting = "Hello, ${userName}!"
        `
      }
    });

    const result = await runMeld('project/main.meld'); 
    expect(result).toContain('Hello, Alice!');
    // Possibly also check state or final output for correctness
  });
});
--------------------------------------------------------------------------------

By applying these patterns, we confirm:

• Interpolation logic is solid in isolation (unit tests).  
• Full pipeline usage works (integration tests).  
• We rely on the new test architecture with ProjectBuilder, Memfs, etc. to keep it all consistent.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VII. IMPLEMENTATION SKETCH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Below is a pseudo-typescript snippet illustrating a clean approach in InterpolationService.ts:

--------------------------------------------------------------------------------
import type { StateService } from '../StateService/StateService';
import type { PathService } from '../PathService/PathService';
import { FormatService } from '../FormatService/FormatService';

export type InterpolationContext = 'text' | 'dataValue' | 'path' | 'command' | ... ;

export class InterpolationService {
  constructor(
    private stateService: StateService,
    private pathService: PathService,
    private formatService?: FormatService
  ) {}

  public resolveString(input: string, context: InterpolationContext): string {
    // 1) token-scan for any references
    // e.g. with a suitable regex or small parser:
    //    /(\${[^}]+})|(\#{[^}]+})|(\$[A-Za-z0-9_]+)/
    // 2) for each match => parse out var name, type, optional format
    // 3) call expandOne(match, context) => returns string
    // 4) replace in the final result

    let result = input;
    // example approach with a simplified pseudo-regex:

    // We'll iterate in a while loop to handle multiple expansions
    // (We must be sure to handle the grammar's constraints)

    // Pseudocode:
    // while we find expansions in result:
    //   const expanded = this.expandOne(matchedString, context)
    //   result = result.replace(matchedString, expanded)

    return result;
  }

  private expandOne(matched: string, context: InterpolationContext): string {
    // Distinguish between ${}, #{}, or $var
    // parse out format if >>(...) is present
    // look up from state or pathService
    // apply format or do JSON stringify if data
    // return final string
  }
}
--------------------------------------------------------------------------------

We’d keep it “easy to read over trying to be super optimized.” The grammar says no nested expansions, so we can do a simpler approach.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIII. CONCLUSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

By introducing this well-bounded InterpolationService:

• We fulfill the Meld spec’s variable interpolation rules without polluting directive handlers.  
• Each directive can simply say “InterpolationService, please expand my directive’s string.”  
• The service delegates variable lookups to StateService and path expansions to PathService.  
• Our tests are straightforward (unit tests with mock services, integration tests with real expansions).  
• We remain strongly aligned with SOLID design, isolating the complexity in an easy-to-maintain service.

The InterpolationService is thus a vital piece in our new codebase. It:

1. Maintains clarity for expansions.  
2. Follows the Meld grammar’s constraints.  
3. Stays test-friendly by injecting only the needed services and having no disk or AST dependencies.  

This closes the loop on how we can handle variable interpolation elegantly and reliably in our new architecture. The patterns outlined above make expansions consistent, thoroughly tested, and trivially extensible (e.g. adding new format operators or new variable types) in the future.
