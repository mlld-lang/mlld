# ValidationService

Below is a specific, SOLID-oriented design for a new ValidationService. It strictly aligns with the Meld grammar and the overall architecture previously described. It ensures each directive’s syntax and arguments conform to the spec, while isolating complexity so each directive handler remains small and clear.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I. PURPOSE & SCOPE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Provide a single “ValidationService” that checks each directive’s syntax and arguments according to the Meld grammar/spec.
2. Keep all directive-specific validations in one place (rather than scattered across handlers).
3. Produce typed errors with location info when validations fail, using ErrorFactory and MeldError structures.

In short, before a directive does anything (like storing variables or embedding files), we run “ValidationService” to confirm that the directive is well-formed and matches Meld grammar constraints.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
II. DIRECTORY STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Under the proposed services/ folder:

services/
 ├─ ValidationService/
 │   ├─ ValidationService.ts
 │   ├─ directiveValidators/
 │   │   ├─ TextDirectiveValidator.ts
 │   │   ├─ DataDirectiveValidator.ts
 │   │   ├─ ImportDirectiveValidator.ts
 │   │   ├─ ...
 │   └─ ValidationService.test.ts
 └─ ...

Recommended sub-structure:

1) ValidationService.ts → Main entry point (public API).  
2) directiveValidators/ → Each file exports a small class or function that knows how to validate a single directive type.  
3) ValidationService.test.ts → High-level unit tests for the entire service. (Integration with the directive handlers tested deeper in directive tests or the interpreter tests.)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
III. SERVICE ROLE IN THE ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ASCII Overiew:

 ┌─────────────────────────┐
 │   DirectiveHandler      │
 │  (e.g., TextDirective)  │
 └───────────┬─────────────┘
             │
     [ directiveNode ]
             │
 ┌───────────v───────────┐
 │   ValidationService    │
 │   (detects any errors) │
 └───────────┬────────────┘
             │
  if valid,   │  if invalid, throw MeldError
             ▼
 ┌─────────────────────────┐
 │  Actual Directive Exec  │
 └─────────────────────────┘

• Each directive handler does:

  validationService.validate(directiveNode);

• If errors are found, a MeldDirectiveError (or chordal sub-error) is thrown with location info.  
• If valid, the handler proceeds with normal logic.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IV. INTERNAL DESIGN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Within ValidationService.ts:

1) A registry of “directiveValidators” keyed by directive kind (e.g. "text", "data", "embed", ...).  
2) A “validate(directiveNode)” method that:  
   • Looks up the correct validator from the registry.  
   • Calls “validator.validate(directiveNode)”.  
   • If no validator is found for a known directive kind, we throw an ErrorFactory.createDirectiveError(...)  

Direct sub-validators are typically small classes or functions:

// Example (directiveValidators/TextDirectiveValidator.ts)
--------------------------------------------------------------------------------
import { MeldNode, DirectiveNode } from '../../core/types/MeldNode';
import { ErrorFactory } from '../../core/errors/ErrorFactory';

export function validateTextDirective(node: DirectiveNode): void {
  // 1) Check name property
  const name = node.directive.name;
  if (!name || typeof name !== 'string') {
    throw ErrorFactory.createDirectiveError(
      'Text directive requires a "name" property (string).',
      'text',
      node.location?.start
    );
  }

  // 2) Check value property is a string
  const value = node.directive.value;
  if (typeof value !== 'string') {
    throw ErrorFactory.createDirectiveError(
      'Text directive "value" must be a string.',
      'text',
      node.location?.start
    );
  }

  // (We can also confirm the grammar constraints around quotes, etc. if needed)
}
--------------------------------------------------------------------------------

We repeat a similar pattern for @data, @path, @import, etc.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
V. CODE EXCERPT FOR THE MAIN VALIDATIONSERVICE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Below is a sample outline:

ValidationService.ts
--------------------------------------------------------------------------------
import { DirectiveNode } from '../../core/types/MeldNode';
import { ErrorFactory } from '../../core/errors/ErrorFactory';
import { MeldDirectiveError } from '../../core/errors/MeldError';
import { validateTextDirective } from './directiveValidators/TextDirectiveValidator';
import { validateDataDirective } from './directiveValidators/DataDirectiveValidator';
import { validateImportDirective } from './directiveValidators/ImportDirectiveValidator';
import { validateEmbedDirective } from './directiveValidators/EmbedDirectiveValidator';

// Type for the registry
type DirectiveValidatorFn = (node: DirectiveNode) => void;

export class ValidationService {
  private validators: Map<string, DirectiveValidatorFn>;

  constructor() {
    this.validators = new Map<string, DirectiveValidatorFn>([
      ['text', validateTextDirective],
      ['data', validateDataDirective],
      ['import', validateImportDirective],
      ['embed', validateEmbedDirective],
      // ... add more
    ]);
  }

  public validateDirective(node: DirectiveNode): void {
    const { kind } = node.directive;
    const validator = this.validators.get(kind);

    if (!validator) {
      throw ErrorFactory.createDirectiveError(
        `No validator found for directive kind: ${kind}`,
        kind,
        node.location?.start
      );
    }

    // Call the directive-specific validator
    validator(node);
  }
}
--------------------------------------------------------------------------------

Directives like @run, @define, @path, and so forth each get their own small validator function or class that we plug into the map.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VI. HOW DIRECTIVE HANDLERS USE THIS SERVICE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

In each directive handler:

--------------------------------------------------------------------------------
export class TextDirectiveHandler {
  // The constructor is injected with references to ValidationService + others
  constructor(
    private validationService: ValidationService,
    private interpolationService: InterpolationService,
    private stateService: StateService
  ) {}

  public execute(node: DirectiveNode) {
    // Step 1: Validate
    this.validationService.validateDirective(node);

    // Step 2: If no errors, proceed with logic
    const { name, value } = node.directive;
    const finalValue = this.interpolationService.resolveAll(value);
    this.stateService.setTextVar(name, finalValue);
  }
}
--------------------------------------------------------------------------------

Hence, each directive’s “execute” remains short. All the “are these fields present and valid?” logic belongs to the ValidationService.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VII. ADVANCED CHECKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The grammar includes constraints like:  
• @import must have a path argument.  
• @embed can have optional “# section,” must not be empty, etc.  
• @path must start with $HOMEPATH or $PROJECTPATH, etc.  
• @data must have valid JSON object or string.  

We’d place these checks in their respective directiveValidators/ files. We can also do:

• “@define cmd = @run [content]” → we confirm the right side is an @run directive. Possibly we just confirm grammar.  
• For multi-line or fuzzy sections, we can do partial checks upfront and leave advanced logic for the directive handler to do with other services if needed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIII. TESTING STRATEGY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

We follow the architecture’s guidelines:

1) Unit Tests in ValidationService.test.ts  
   - We directly instantiate a ValidationService.  
   - Pass in mock DirectiveNodes for each directive type.  
   - Expect pass/fail scenarios.  
   - Example:

--------------------------------------------------------------------------------
// tests/unit/ValidationService/ValidationService.test.ts

import { describe, it, expect, beforeEach } from 'vitest';
import { ValidationService } from '../../../services/ValidationService/ValidationService';
import { DirectiveNode } from '../../../core/types/MeldNode';
import { ErrorFactory } from '../../../core/errors/ErrorFactory';

describe('ValidationService (unit)', () => {
  let service: ValidationService;

  beforeEach(() => {
    service = new ValidationService();
  });

  it('validates a valid @text directive', () => {
    const node: DirectiveNode = {
      type: 'Directive',
      directive: {
        kind: 'text',
        name: 'hello',
        value: 'world'
      },
      location: { start: { line: 1, column: 1 }, end: { line: 1, column: 20 } }
    };
    expect(() => service.validateDirective(node)).not.toThrow();
  });

  it('throws error if @text has no name', () => {
    const node: DirectiveNode = {
      type: 'Directive',
      directive: {
        kind: 'text',
        // missing name
        value: 'something'
      },
      location: { start: { line: 1, column: 1 }, end: { line: 1, column: 20 } }
    };
    expect(() => service.validateDirective(node)).toThrow(
      /requires a "name" property/
    );
  });

  // more tests for other directives...
});
--------------------------------------------------------------------------------

2) Integration Tests (e.g. interpret tests)  
   - The directive handler calls ValidationService under the hood.  
   - If invalid, the test can expect an error from the “interpret” pipeline.  
   - We rely on the overall architecture’s integration testing patterns.

3) Using The Proposed Test Infrastructure  
   - Typically, we do not need file manipulation for pure validation.  
   - However, for integration tests that load a .meld file from a mock FS, parse it, interpret it, we’ll see if ValidationService complains about syntax.  
   - Example: interpretEmbed.test.ts might feed a directive that references invalid embed syntax, expecting an error.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IX. ISOLATION & COMPLEXITY MANAGEMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• We never do filesystem checks inside the ValidationService. That belongs in the directive handler or other service to confirm the file actually exists, etc.  
• We do not read or write any state here; we only confirm that the directive’s syntax meets grammar constraints.  
• Each directive’s specialized logic is self-contained in its sub-validator (e.g. DataDirectiveValidator for JSON checks, PathDirectiveValidator for path format syntax) so that the main “ValidationService” remains a small orchestrator.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
X. POSSIBLE FUTURE EXTENSIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. “Fuzzy Validation” for partial matches. E.g., if the directive has a near-miss key. We can do suggestions.  
2. Type Awareness. We could parse numeric or boolean fields.  
3. Advanced directive cross-checks. E.g., a “@run” directive might require environment variables to be defined first. That logic might remain in the interpreter, or we could add an optional “context” parameter to validation that can see if certain required states exist.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
XI. CONCLUSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This design ensures:
• All syntactic correctness checks live in a single dedicated ValidationService.  
• Each directive’s checker is easy to read and test.  
• Directives themselves remain small, focusing on actual business logic.  
• The rest of the codebase can trust that when a directive is run, it’s guaranteed to meet the Meld grammar requirements.

In synergy with the rest of the SOLID architecture, we get a thoroughly maintainable codebase:
• Minimal duplication (shared error creation patterns).  
• Extensible for future directives or grammar changes.  
• Thorough test coverage via targeted unit tests + top-level integration tests.

By building out each sub-validator, hooking them into the main “ValidationService,” and referencing that service in every directive handler’s “execute” method, we achieve strong, clear separation of concerns that we can confidently expand upon.
