# StateService

Below is a detailed design for the StateService in our Meld architecture. The goal is for this service to manage all Meld variables (text, data, path, define commands, etc.), track child-state merges (e.g. imports), preserve correct scoping, and make it seamlessly testable and extendable. This design builds on the proposed services-based approach and leverages the new test architecture.


TABLE OF CONTENTS
────────────────────────────────────────────────────────────────────────────
1) Overview & Goals
2) Meld State Requirements
3) State Service Responsibilities
4) Code Structure & Interfaces
5) ASCII Illustrations
6) Detailed Implementation Considerations
7) Example Usage from a Directive
8) Testing Strategy
9) Future Extensions
10) Conclusion

────────────────────────────────────────────────────────────────────────────
1) OVERVIEW & GOALS
────────────────────────────────────────────────────────────────────────────

We want a dedicated “StateService” that:

• Holds the current set of Meld variables, commands, and references.  
• Creates, reads, updates, merges states without polluting business logic.  
• Maintains merges for nested “import” or “embed” usage.  
• Is fully testable in isolation, following SOLID.  
• Exposes a clear API for directive handlers and the InterpreterService.  

We explicitly separate concerns:  
• “StateService” is about storing and merging state.  
• “InterpolationService,” “PathService,” “ValidationService,” etc. remain separate.  


────────────────────────────────────────────────────────────────────────────
2) MELD STATE REQUIREMENTS
────────────────────────────────────────────────────────────────────────────

According to the Meld grammar & UX, we have:

• Text Variables:  
  - @text directive sets text variables (string).  
  - Also used by define, interpolation, etc.  

• Data Variables:  
  - @data directive sets structured JSON-like objects.  
  - Potential field access (like #{config.key}).  

• Path Variables:  
  - @path directive sets path-based variables ($PROJECTPATH, $HOMEPATH expansions).  
  - Typically only used in path contexts.  

• Commands (Defines):  
  - @define directive can store a custom “command” or function reference.  
  - Potentially used by @run.  

• Imports:  
  - We track which files have been imported for possible circularity detection.  

• Child States & Merging:  
  - “import sub.meld” or “embed sub.meld” can produce a child state that merges back.  
  - The service must handle merging collisions, shadowing, or same-named variables carefully.  

Additionally, we might have special constraints:
• Immutability or partial immutability after interpretation.  
• Possibly track “local changes” for debugging.  

────────────────────────────────────────────────────────────────────────────
3) STATE SERVICE RESPONSIBILITIES
────────────────────────────────────────────────────────────────────────────

RESPONSIBILITY #1: Variable Storage  
• Store text variables (@text)  
• Store data variables (@data)  
• Store path variables (@path)  
• Store commands (@define)  

RESPONSIBILITY #2: Merging of Child States  
• Provide “createChildState()” or similar.  
• Then “mergeChild(childState)” merges that child’s variables back.  

RESPONSIBILITY #3: Optional Immutability  
• After interpretation, we can lock the state from further changes, preventing accidental modifications.  

RESPONSIBILITY #4: Import Tracking  
• Keep track of which files or references have been imported in this state.  
• Possibly used by a separate “CircularityService”, but StateService can store the record.  

RESPONSIBILITY #5: Change Tracking & Debugging  
• Optionally track all variable sets or merges for debug.  
• Provide easy ways for integration tests to see which variables got created.  

────────────────────────────────────────────────────────────────────────────
4) CODE STRUCTURE & INTERFACES
────────────────────────────────────────────────────────────────────────────

PROJECT LAYOUT (HIGH-LEVEL)
────────────────────────────────────────────────────────────────────────────
services/
 ├─ StateService/
 │   ├─ StateService.ts
 │   ├─ StateService.test.ts
 │   └─ (optional submodules, e.g., ChildState.ts or merges logic)
 ...
(interpolation, path, directive, etc. remain separate)

StateService.ts (SUGGESTED INTERFACE)
────────────────────────────────────────────────────────────────────────────
export interface IStateService {
  // Text variables
  setTextVar(name: string, value: string): void;
  getTextVar(name: string): string | undefined;

  // Data variables
  setDataVar(name: string, value: any): void;
  getDataVar(name: string): any;

  // Path variables
  setPathVar(name: string, value: string): void;
  getPathVar(name: string): string | undefined;

  // Commands
  setCommand(name: string, command: CommandDefinition): void;
  getCommand(name: string): CommandDefinition | undefined;

  // Import Tracking
  addImportedFile(filePath: string): void;
  hasImportedFile(filePath: string): boolean;

  // Child States
  createChildState(): IStateService;
  mergeChildState(child: IStateService): void;

  // Immutability
  setImmutable(): void;
  isImmutable(): boolean;

  // Debug / Snapshot
  getAllVariables(): FullStateSnapshot;  // e.g. { textVars:..., dataVars:..., ... }
}

// The internal shape for a “CommandDefinition”
export interface CommandDefinition {
  // e.g. for @define, we might store a function or a string representing how to run it
  // This might grow later with risk fields, etc.
  content: string;
  risk?: 'high' | 'med' | 'low';
  about?: string;
}

// The shape for the full snapshot if needed
export interface FullStateSnapshot {
  textVars: Record<string, string>;
  dataVars: Record<string, any>;
  pathVars: Record<string, string>;
  commands: Record<string, CommandDefinition>;
  imports: string[];
}

EXAMPLE Implementation
────────────────────────────────────────────────────────────────────────────
export class StateService implements IStateService {
  private textVars = new Map<string, string>();
  private dataVars = new Map<string, any>();
  private pathVars = new Map<string, string>();
  private commands = new Map<string, CommandDefinition>();
  private importedFiles = new Set<string>();
  private immutable = false;
  private parent?: StateService;

  constructor(parent?: StateService) {
    this.parent = parent;
  }

  // TEXT
  setTextVar(name: string, value: string): void {
    this.checkImmutable();
    this.textVars.set(name, value);
  }
  getTextVar(name: string): string | undefined {
    if (this.textVars.has(name)) return this.textVars.get(name);
    return this.parent?.getTextVar(name);
  }

  // DATA
  setDataVar(name: string, value: any): void {
    this.checkImmutable();
    this.dataVars.set(name, value);
  }
  getDataVar(name: string): any {
    if (this.dataVars.has(name)) return this.dataVars.get(name);
    return this.parent?.getDataVar(name);
  }

  // PATH
  setPathVar(name: string, value: string): void {
    this.checkImmutable();
    this.pathVars.set(name, value);
  }
  getPathVar(name: string): string | undefined {
    if (this.pathVars.has(name)) return this.pathVars.get(name);
    return this.parent?.getPathVar(name);
  }

  // COMMANDS
  setCommand(name: string, cmd: CommandDefinition): void {
    this.checkImmutable();
    this.commands.set(name, cmd);
  }
  getCommand(name: string): CommandDefinition | undefined {
    if (this.commands.has(name)) return this.commands.get(name);
    return this.parent?.getCommand(name);
  }

  // IMPORTS
  addImportedFile(filePath: string): void {
    this.checkImmutable();
    this.importedFiles.add(filePath);
  }
  hasImportedFile(filePath: string): boolean {
    if (this.importedFiles.has(filePath)) return true;
    return this.parent?.hasImportedFile(filePath) || false;
  }

  // Child States
  createChildState(): IStateService {
    const child = new StateService(this);
    return child;
  }

  mergeChildState(child: IStateService): void {
    this.checkImmutable();
    // For each variable in child, override or shadow here
    const snapshot = child.getAllVariables();
    Object.entries(snapshot.textVars).forEach(([k, v]) => this.textVars.set(k, v));
    Object.entries(snapshot.dataVars).forEach(([k, v]) => this.dataVars.set(k, v));
    Object.entries(snapshot.pathVars).forEach(([k, v]) => this.pathVars.set(k, v));
    Object.entries(snapshot.commands).forEach(([k, v]) => this.commands.set(k, v));
    snapshot.imports.forEach(i => this.importedFiles.add(i));
  }

  // Immutability
  setImmutable(): void { this.immutable = true; }
  isImmutable(): boolean { return this.immutable; }
  private checkImmutable(): void {
    if (this.immutable) {
      throw new Error('Cannot modify an immutable state.');
    }
  }

  // DEBUG
  getAllVariables(): FullStateSnapshot {
    return {
      textVars: Object.fromEntries(this.textVars.entries()),
      dataVars: Object.fromEntries(this.dataVars.entries()),
      pathVars: Object.fromEntries(this.pathVars.entries()),
      commands: Object.fromEntries(this.commands.entries()),
      imports: Array.from(this.importedFiles)
    };
  }
}

────────────────────────────────────────────────────────────────────────────
5) ASCII ILLUSTRATIONS
────────────────────────────────────────────────────────────────────────────

CHILD STATES & MERGES
────────────────────────────────────────────────────────────────────────────
Consider fileA imports fileB → we create a child for B, interpret B, then merge:

 ┌─────────────┐       (A State)
 │ ParentState │  e.g. textVars = { "parentVar": "p" }
 └──────┬───────┘
        │ createChildState()
        ▼
 ┌────────────────┐
 │ ChildState (B) │ e.g. textVars = { "childVar": "c" }
 └────────────────┘
        |
        │ interpret fileB
        |
        ▼
 parentState.mergeChildState(child)

Now the parent has textVars = { "parentVar": "p", "childVar": "c" }

────────────────────────────────────────────────────────────────────────────
6) DETAILED IMPLEMENTATION CONSIDERATIONS
────────────────────────────────────────────────────────────────────────────

• Collisions: If the same variable name is set in both parent and child, the child’s value overwrites upon merge. This is typical “last-writer-wins.”  
• Private vs. Parent: If we do getTextVar(“X”) and child does not have “X,” we bubble up.  
• Shadowing: If the child defines “X,” we see that value in the child, but parent’s “X” remains if we do not merge.  
• Circular tracking for imports is not done here but we do store the “importedFiles” for convenience. The “CircularityService” might consult that.  
• Possibly we’ll store environment variables as well. That can be done in dataVars or a separate map.  

────────────────────────────────────────────────────────────────────────────
7) EXAMPLE USAGE FROM A DIRECTIVE
────────────────────────────────────────────────────────────────────────────

Pseudo-code in a directive (TextDirectiveHandler):
────────────────────────────────────────────────────────────────────────────
class TextDirectiveHandler {
  constructor(private state: IStateService, private validation: IValidationService) {}

  execute(node: DirectiveNode) {
    this.validation.validateTextNode(node);
    const name = node.directive.name;
    const value = node.directive.value;

    // Set in state
    this.state.setTextVar(name, value);
  }
}
────────────────────────────────────────────────────────────────────────────

Then if we do “import” a child file, the “ImportDirectiveHandler” might do:
────────────────────────────────────────────────────────────────────────────
class ImportDirectiveHandler {
  constructor(private state: IStateService,
              private fileSystem: IFileSystemService,
              private interpreter: IInterpreterService) {}

  execute(node: DirectiveNode) {
    const childFile = node.directive.source;
    this.state.addImportedFile(childFile);    // record import
    // create child state
    const childState = this.state.createChildState();

    // read, parse, interpret
    const content = this.fileSystem.readFile(childFile);
    const ast = this.interpreter.parse(content);
    this.interpreter.run(ast, childState);

    // merge back
    this.state.mergeChildState(childState);
  }
}
────────────────────────────────────────────────────────────────────────────

────────────────────────────────────────────────────────────────────────────
8) TESTING STRATEGY
────────────────────────────────────────────────────────────────────────────

We use the new ephemeral test architecture with Memfs or a similarly mocked FS. We test the StateService in two levels:

UNIT TESTS
────────────────────────────────────────────────────────────────────────────
In tests/unit/StateService.test.ts:

• We instantiate a new StateService, call setTextVar, getTextVar, etc.  
• We confirm merges, collisions, immutability.  
• No real files or path expansions needed—pure in-memory tests.  
• Example:

tests/unit/StateService.test.ts
────────────────────────────────────────────────────────────────────────────
import { describe, it, expect, beforeEach } from 'vitest';
import { StateService } from '../../../services/StateService/StateService';

describe('StateService (unit)', () => {
  let state: StateService;

  beforeEach(() => {
    state = new StateService();
  });

  it('stores and retrieves text vars', () => {
    state.setTextVar('greeting', 'Hello');
    expect(state.getTextVar('greeting')).toBe('Hello');
  });

  it('merges child states, overrides collisions', () => {
    state.setTextVar('parent', 'p-value');
    const child = state.createChildState();
    child.setTextVar('child', 'c-value');
    child.setTextVar('parent', 'override');

    state.mergeChildState(child);

    expect(state.getTextVar('parent')).toBe('override');
    expect(state.getTextVar('child')).toBe('c-value');
  });
});
────────────────────────────────────────────────────────────────────────────

INTEGRATION TESTS
────────────────────────────────────────────────────────────────────────────
We then do a bigger “interpreter” or “directive” test in tests/integration, instantiating an in-memory FS plus all services, verifying that the final state has the correct variables. This ensures the StateService works well with the rest of the pipeline.

Example:
────────────────────────────────────────────────────────────────────────────
describe('InterpreterService with real StateService', () => {
  it('interprets multiple directives and merges state', async () => {
    // 1) Build a test project in memfs
    // 2) parse & interpret
    // 3) read final state
    // 4) validate text/data vars are as expected
  });
});
────────────────────────────────────────────────────────────────────────────

We can also use snapshots (TestSnapshot) to confirm no extraneous changes.  

────────────────────────────────────────────────────────────────────────────
9) FUTURE EXTENSIONS
────────────────────────────────────────────────────────────────────────────

Potential expansions for the StateService:

• “Partial Locking” – we could make certain variables read-only.  
• “Nested Namespaces” – if we want to isolate variables by directive or scope.  
• “Garbage Collection” – if we have giant data sets, we might remove unreferenced data.  
• “Versioning” – we might keep diffs or small commits for advanced debugging.  

────────────────────────────────────────────────────────────────────────────
10) CONCLUSION
────────────────────────────────────────────────────────────────────────────

This State Service design closely follows the Meld grammar’s variable model and the new SOLID architecture:

• We isolate variable storage in a single place.  
• We provide merges & child states for @import.  
• We track immutability, ensuring we can “lock” the state at the end of interpretation.  
• Testing is straightforward: minimal in-unit tests, plus integration with the rest via the new test framework.  
• This design is maintainable, easy to reason about, and ready for expansions.  

By following these guidelines, we maintain a SOLID, robust structure that fully respects the Meld grammar and remains easy to test and evolve. This is a core building block for the entire codebase, ensuring stable variable management across all directives and sub-services.
