# meld Testing Setup

Below is a comprehensive proposal for a new end-to-end test setup that both complements the services-based Meld architecture and meets the stated test goals of zero path‐manipulation, declarative project structures, isolation, and easy debugging. It is specific and opinionated, focusing on clarity and maintainability over complexity or performance.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I. HIGH-LEVEL TEST FOLDER STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

A recommended top-level layout for tests:

tests/
 ├─ unit/
 │   ├─ PathService.test.ts
 │   ├─ FileSystemService.test.ts
 │   ├─ StateService.test.ts
 │   ├─ DirectiveService/
 │   │   ├─ TextDirectiveHandler.test.ts
 │   │   ├─ DataDirectiveHandler.test.ts
 │   │   ├─ ImportDirectiveHandler.test.ts
 │   │   └─ ...
 │   └─ ...
 ├─ integration/
 │   ├─ interpreter/
 │   │   ├─ interpretSimple.test.ts
 │   │   ├─ interpretEmbed.test.ts
 │   │   ├─ interpretImport.test.ts
 │   │   └─ ...
 │   ├─ sdk/
 │   │   ├─ runMeldBasics.test.ts
 │   │   ├─ runMeldComplex.test.ts
 │   │   └─ ...
 │   └─ ...
 ├─ fixtures/
 │   ├─ basicProject.json
 │   ├─ complexEmbed.json
 │   └─ ...
 └─ utils/
     ├─ index.ts                 # Re-exports below classes for convenience
     ├─ TestContext.ts           # Main test context API
     ├─ MemfsTestFileSystem.ts   # In-memory FS with memfs
     ├─ ProjectBuilder.ts        # Creates files & dirs from a simple object
     ├─ TestSnapshot.ts          # Snapshot & diff utilities
     ├─ PathUtils.ts             # Minimal path helper if needed
     ├─ FixtureManager.ts        # Load & store JSON-based project fixtures
     ├─ matchers.ts              # (Optional) Custom Vitest matchers
     └─ ...

With this arrangement:
• /unit focuses on direct, isolated service tests (PathService, StateService, each directive handler, etc.).  
• /integration focuses on multi-step flows (importing, embedding, interpreting entire documents, or the CLI flow).  
• /fixtures holds static JSON (or YAML) descriptions of file structures used in integration tests.  
• /utils houses all the reusable test utilities.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
II. CORE UTILITIES & THEIR RESPONSIBILITIES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) MemfsTestFileSystem
─────────────────────────────────────────────────────────────────────────
• Underlying in-memory file system using memfs (or a custom sim).  
• Responsible for reading/writing files, verifying existence, etc. but never forces the test to handle real paths.  
• Enforces no "../" or raw path manipulation in test code.  
• Typically you do: testFS.writeFile("project/alpha.meld", "...").

Example (MemfsTestFileSystem.ts):
--------------------------------------------------------------------------------
import { Volume } from 'memfs';

export class MemfsTestFileSystem {
  private vol: Volume;

  constructor() {
    this.vol = new Volume();
  }

  initialize(): void {
    // Clear out any prior state
    this.vol.reset();
  }

  writeFile(filePath: string, content: string): void {
    this.ensureFileParentDirs(filePath);
    this.vol.writeFileSync(filePath, content, 'utf-8');
  }

  readFile(filePath: string): string {
    return this.vol.readFileSync(filePath, 'utf-8') as string;
  }

  exists(filePath: string): boolean {
    return this.vol.existsSync(filePath);
  }

  // create parent dirs if needed
  private ensureFileParentDirs(filePath: string) {
    // ...
  }

  // Additional directory listing, removal, etc. as needed
}
--------------------------------------------------------------------------------

2) ProjectBuilder
─────────────────────────────────────────────────────────────────────────
• A higher-level builder that creates an entire “fake project” by calling MemfsTestFileSystem behind the scenes.  
• Accepts a data structure like { files: { "some.meld": "...", "dir/sub.meld": "..." }, dirs?: [...] }  
• Auto-creates parent directories.  
• Supports advanced patterns if needed (like placeholders for $PROJECTPATH or $HOMEPATH expansions).

Example (ProjectBuilder.ts):
--------------------------------------------------------------------------------
export interface ProjectStructure {
  files: Record<string, string>;
  dirs?: string[];
}

export class ProjectBuilder {
  constructor(private fs: MemfsTestFileSystem) {}

  async create(struct: ProjectStructure): Promise<void> {
    // Create dirs first
    for (const dir of struct.dirs || []) {
      if (!this.fs.exists(dir)) {
        // We rely on fs to create recursively
        this.fs.writeFile(dir + '/.keep', '');
      }
    }
    // Create files
    for (const [path, content] of Object.entries(struct.files)) {
      this.fs.writeFile(path, content);
    }
  }
}
--------------------------------------------------------------------------------

3) TestSnapshot
─────────────────────────────────────────────────────────────────────────
• Utility to snapshot the current file system state (just a map of filePath → content).  
• Later we compare to see which files changed, were added, or removed.

Example (TestSnapshot.ts):
--------------------------------------------------------------------------------
export class TestSnapshot {
  constructor(private fs: MemfsTestFileSystem) {}

  takeSnapshot(): Map<string, string> {
    // For each file in the volume, read the content
    // Return as a map
  }

  compare(before: Map<string, string>, after: Map<string, string>) {
    const result = { added: [] as string[], removed: [] as string[], modified: [] as string[] };
    // ...
    return result;
  }
}
--------------------------------------------------------------------------------

4) FixtureManager
─────────────────────────────────────────────────────────────────────────
• Loads a JSON fixture that describes files & dirs, then calls ProjectBuilder to create them.  
• This allows tests to simply do fixtureManager.load("basicProject").

Example (FixtureManager.ts):
--------------------------------------------------------------------------------
import { ProjectBuilder } from './ProjectBuilder';
import * as path from 'path';
import * as fs from 'fs';

export class FixtureManager {
  constructor(private builder: ProjectBuilder, private fixturesDir: string) {}

  load(fixtureName: string): void {
    const filePath = path.join(this.fixturesDir, fixtureName + '.json');
    if (!fs.existsSync(filePath)) {
      throw new Error(`Fixture not found: ${fixtureName}`);
    }
    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    this.builder.create(data);
  }
}
--------------------------------------------------------------------------------

5) TestContext
─────────────────────────────────────────────────────────────────────────
• The top-level object that a typical test instantiates.  
• Composes the MemfsTestFileSystem + ProjectBuilder + FixtureManager, etc.  
• Typically we do: const context = new TestContext(); context.initialize(); context.builder.create(...).

Example (TestContext.ts):
--------------------------------------------------------------------------------
export class TestContext {
  public fs: MemfsTestFileSystem;
  public builder: ProjectBuilder;
  public snapshot: TestSnapshot;
  public fixtures: FixtureManager;

  constructor(private fixturesDir: string = 'tests/fixtures') {
    this.fs = new MemfsTestFileSystem();
    this.builder = new ProjectBuilder(this.fs);
    this.snapshot = new TestSnapshot(this.fs);
    this.fixtures = new FixtureManager(this.builder, this.fixturesDir);
  }

  initialize(): void {
    this.fs.initialize();
  }

  cleanup(): void {
    // Could do any tear-down, if needed
  }
}
--------------------------------------------------------------------------------

6) PathUtils (Optional)
─────────────────────────────────────────────────────────────────────────
• If we want to avoid any path string manipulation in test code, we might store standard keys for “project root” or “home root” in the Memfs.  
• Usually the approach is: we treat "project/" or "home/" as symbolic top-level dirs in the memfs.  
• E.g. context.fs.writeFile("project/test.meld", "...").

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
III. EXAMPLE TEST CODE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Here’s how a directive test might look using these utilities:

tests/unit/DirectiveService/TextDirectiveHandler.test.ts
--------------------------------------------------------------------------------
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { TestContext } from '../../utils/TestContext';
// import { TextDirectiveHandler } from '../../../services/DirectiveService/handlers/TextDirectiveHandler';
// import { StateService } from '../../../services/StateService/StateService';

describe('TextDirectiveHandler (unit)', () => {
  let context: TestContext;
  // let handler: TextDirectiveHandler;
  // let state: StateService;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();
    // state = new StateService();
    // handler = new TextDirectiveHandler(validationService, interpolationService, state);
  });

  afterEach(() => {
    context.cleanup();
  });

  it('should set a text variable', async () => {
    // 1) Create a minimal file that references @text
    await context.builder.create({
      files: {
        'test.meld': '@text greeting = "Hello world"'
      }
    });
    // 2) Then parse & interpret that file using the real directive
    //   (In a real test, we'd call parseMeld() -> interpreter -> directive)
    // For demonstration, we might do:
    // const ast = parserService.parse('test.meld' content)
    // interpreterService.run(ast, state)
    // expect(state.getTextVar('greeting')).toBe('Hello world')
    expect(true).toBe(true); // placeholder
  });
});
--------------------------------------------------------------------------------

Then, in an integration test:

tests/integration/interpreter/interpretEmbed.test.ts
--------------------------------------------------------------------------------
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { TestContext } from '../../utils/TestContext';
import { runMeld } from '../../../sdk';

describe('Interpreter - @embed directive (integration)', () => {
  let context: TestContext;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();
  });

  afterEach(() => {
    context.cleanup();
  });

  it('embeds content from an external file', async () => {
    // Setup
    await context.builder.create({
      files: {
        'doc.meld': '@embed [other.meld # Section One]',
        'other.meld': `
          # Section One
          Some embedded content
        `
      }
    });

    // Act
    const result = await runMeld('doc.meld'); // Suppose runMeld uses the in-mem FS

    // Assert: result should contain the embedded content
    expect(result).toContain('Some embedded content');
  });
});
--------------------------------------------------------------------------------

Notice that in these examples, test code never deals with raw path strings like "/test/_tmp/project/doc.meld". Instead we use "doc.meld" or "project/doc.meld" as a short reference. The MemfsTestFileSystem treats "project/" as top-level or we can treat "doc.meld" as being in the root.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IV. BEST PRACTICES & PATTERNS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Use Distinct Folders For “project” & “home”
─────────────────────────────────────────────────────────────────────────
• If a test simulates $PROJECTPATH or $HOMEPATH, we treat "project/" and "home/" in the memfs as placeholders.  
• E.g. context.builder.create({ files: { "project/main.meld": ... } }).

2. Clear Separation of Unit vs Integration
─────────────────────────────────────────────────────────────────────────
• In unit tests, we pass in the MemfsTestFileSystem or a similarly minimal mock directly to a single service.  
• In integration tests, we set up an entire environment with multiple files and run them through parse → interpret → output.

3. Consistent Setup and Teardown
─────────────────────────────────────────────────────────────────────────
• Always call context.initialize() in beforeEach, context.cleanup() in afterEach.  
• Let your framework do it so tests remain stateless.

4. Named Fixtures For Reusability
─────────────────────────────────────────────────────────────────────────
• If we have a standard “basicProject” fixture, store it in fixtures/basicProject.json like:

  {
    "dirs": ["project", "home"],
    "files": {
      "project/fileA.meld": "@text a = 'A'",
      "home/config/foo.meld": "..."
    }
  }

• Then in a test: context.fixtures.load("basicProject").

5. Snapshot Testing For Complex Flows
─────────────────────────────────────────────────────────────────────────
• Use TestSnapshot to capture FS state before and after.  
• Helps detect which files got created/modified by the interpreter.  
• Example:
--------------------------------------------------------------------------------
// Pseudo-tests using snapshots
it('creates an output file', async () => {
  const before = context.snapshot.takeSnapshot();
  await runMeld('project/source.meld');
  const after = context.snapshot.takeSnapshot();
  const diff = context.snapshot.compare(before, after);
  expect(diff.added).toContain('project/output.md');
});
--------------------------------------------------------------------------------

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
V. PUTTING IT ALL TOGETHER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• By using the above approach, our tests remain laser-focused on Meld logic, not on path manipulation or OS intricacies.  
• The in-memory FS is reset every test. The directives or the entire interpreter see a consistent, isolated environment.  
• We combine fixture-based or ad-hoc setups.  
• We easily read or verify file contents without wrestling with real disk or absolute paths.

Example final usage in an advanced scenario:

--------------------------------------------------------------------------------
describe('ImportDirective + Embedded Sub-Imports (integration)', () => {
  let context: TestContext;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();
  });

  afterEach(() => context.cleanup());

  it('handles multi-level import chains, ensures no circular references', async () => {
    // 1) Load a fixture or builder creation
    context.builder.create({
      dirs: ['project', 'home'],
      files: {
        'project/fileA.meld': `
          @import [fileB.meld]
          @embed [fileC.meld]
          @text final = "Done!"
        `,
        'project/fileB.meld': `
          @text fromB = "B Content"
        `,
        'project/fileC.meld': `
          # Some Markdown
          # Section 1
          Embedded Content
        `
      }
    });

    // 2) Act
    const result = await runMeld('project/fileA.meld');
    // 3) Assert
    expect(result).toContain('B Content');
    expect(result).toContain('Embedded Content');
    expect(result).toContain('Done!');
  });
});
--------------------------------------------------------------------------------

That’s the shape of an ideal test setup that is easy to read, uses no raw path manipulations, isolates the environment, and encourages “SOLID” test design.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VI. CONCLUSION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

By institutionalizing this new structure and these supporting utilities, we achieve:

• Full alignment with the new services-based Meld architecture—each service is testable in isolation.  
• Zero manual path manipulation in tests.  
• Declarative, easy-to-read steps.  
• Confidence that each test has a fresh in-mem environment, snapshot/diff tooling for advanced checks, and a straightforward approach to file creation and inspection.  

This plan gives us a robust, well-organized test environment that you can be proud of, strongly aligned with SOLID principles, the Meld grammar + UX spec, and the immediate rewrite goals.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VII. ADDITIONAL NOTE FROM EXTERNAL REVIEWER
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

We could implement this incrementally:

1. First create the basic MemfsTestFileSystem using memfs
2. Then add ProjectBuilder for higher-level operations
3. Gradually introduce fixtures for common scenarios
4. Finally add snapshot/diffing capabilities

One area I might suggest expanding slightly is error handling and debugging. We might want to add:

```typescript
class TestContext {
  // ... existing code ...

  // Debug helper
  debugFs(): string {
    return this.fs.printTree();  // Pretty-print current fs state
  }

  // Error wrapping
  wrapFsError(error: Error): TestError {
    // Convert cryptic fs errors to test-friendly ones
  }
}
```