# ParserService

Below is a focused, service-based design for the new ParserService. It is fully aligned with the “services” architecture you are implementing, the Meld grammar + UX spec, and the emphasis on SOLID, testable, maintainable code. This design will help keep complexity isolated, ensure we can precisely parse Meld documents into well-formed AST nodes, and set a strong foundation for future expansions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I. OVERVIEW & GOALS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) Comply with the Meld grammar & UX spec (directives, code fences, string literals, placeholders, etc.).  
2) Produce a clean Meld AST: a typed array of MeldNodes (DirectiveNode, TextNode, CodeFenceNode, etc.).  
3) Store accurate location data (line/column) for improved error reporting in higher layers (InterpreterService).  
4) Keep the parser logic self-contained, testable, and easy to maintain.  
5) Avoid parsing side-effects: The parser does not interpret directives or read files; it only transforms raw content into an AST.  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
II. WHERE THE PARSER FITS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Like all services, the ParserService is invoked as soon as we have raw string content:

┌─────────────┐      (Meld file text)      ┌────────────────────┐
│ FileSystem   │ ─────────────────────────> │     ParserService   │
│  Service     │                            └────────────────────┘
│   (reads)    │                            (AST: MeldNodes[])
└─────────────┘

The InterpreterService later consumes the AST:

┌────────────────────┐     ┌────────────────────────┐
│    ParserService   │─→AST→│ InterpreterService     │
│ (pure text->AST)   │     │  (directive logic)     │
└────────────────────┘     └────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
III. CODE STRUCTURE & DATA FLOW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Recommended directory layout (aligned with your architecture):

parser/
 ├─ ParserService.ts
 ├─ Lexer.ts          (optional sub-layer)
 ├─ ParserImpl.ts     (optional sub-layer)
 ├─ grammar/          (if we store EBNF, nearley, etc.)
 └─ ParserService.test.ts

Testing files typically live in tests/unit/parser/ParserService.test.ts in your bigger structure, or close by.

High-level steps in the ParserService:

1) Split or tokenize the raw Meld content (line-based, or with a small “Lexer”).  
2) Identify code fences, directives, text blocks, triple-backtick fences, etc.  
3) Build MeldNodes with relevant data:  
   • type: "Directive" | "Text" | "CodeFence"  
   • location: { start: { line, col }, end: { line, col } }  
   • content or directive data  
4) Return an array of MeldNodes in document order.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IV. ASCII ILLUSTRATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Below: A high-level flow from raw text to MeldNode[].

    ┌─────────────────────────────────────────────────┐
    │       Raw Meld Document (string content)       │
    └─────────────────────────────────────────────────┘
                       │
                       ▼
            ┌────────────────────────┐
            │ Lexer (optional layer) │
            │  - Splits lines        │
            │  - Recognizes code     │
            │    fence boundaries    │
            └────────────────────────┘
                       │
                       ↓ tokens
            ┌────────────────────────┐
            │  ParserImpl (optional) │
            │   - Takes tokens       │
            │   - Builds MeldNodes   │
            └────────────────────────┘
                       │
                       ▼
            ┌────────────────────────┐
            │   ParserService API    │
            │   parseMeld(content)   │
            └────────────────────────┘
                       │
                       ▼
                 MeldNode[]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
V. SERVICE DESIGN DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Below is a recommended approach for implementing the ParserService that remains simple yet robust enough for Meld’s grammar.

1) Minimal or No External Parser Lib (Line-Based Approach)
   - Because Meld grammar revolves around line-based directives (“@...”), code fences, triple-backticks, etc., we can implement a line-based scanning approach.  
   - Alternatively, we can adopt a formal EBNF grammar with a library like nearley or Chevrotain, but a line-based parser is often easiest for Markdown-like syntax.

2) Data Structures (MeldNodes):
   - DirectiveNode: { type: "Directive", directive: { kind: string, ... }, location }
   - TextNode:      { type: "Text", content: string, location }
   - CodeFenceNode: { type: "CodeFence", content: string, language?: string, location }

3) Location Tracking:
   - For each line or token, track lineNumber + column offset.  
   - For code fences, we note the start line/col at the line with the fence markers, and the end line/col when we see the matching fence.  

4) Handling Meld Grammar:
   - Directives appear at start of line with “@directive”.  
   - Code fences appear at start of line with triple-backticks (or more).  
   - Comments appear at start of line with “>> ”.  
   - Lines that are not recognized as directives or code fences become “TextNode”.  

5) Outline of parseMeld(content):
   A) Split content by lines.  
   B) For line i in lines:  
      - If it starts with “```” or more backticks => parse code fence block.  
      - Else if it starts with “@” => parse it as a directive line.  
      - Else => store as a standard text line.  
   C) Return an array of MeldNodes with location data.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VI. SAMPLE CODE SCAFFOLD
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Below is a conceptual skeleton for clarity (not final code). We adopt a moderately straightforward line-based approach:

--------------------------------------------------------------------------------
// parser/ParserService.ts
import type { MeldNode, DirectiveNode, TextNode, CodeFenceNode, Location } from '../core/types';
import { MeldParseError } from '../core/errors/MeldError';

export class ParserService {
  constructor(/* possibly inject Logger? or config? */) {}

  parseMeld(content: string): MeldNode[] {
    const lines = content.split('\n');
    const nodes: MeldNode[] = [];

    let lineIndex = 0;

    while (lineIndex < lines.length) {
      const line = lines[lineIndex];
      // Calculate line location
      const locationStart = { line: lineIndex + 1, column: 1 };

      if (this.isCodeFenceStart(line)) {
        const fenceNode = this.parseCodeFence(lines, lineIndex);
        nodes.push(fenceNode.node);
        lineIndex = fenceNode.nextLineIndex;
      } else if (this.isDirectiveLine(line)) {
        const directiveNode = this.parseDirective(line, lineIndex);
        nodes.push(directiveNode);
        lineIndex++;
      } else {
        // Normal text or blank line
        const textNode: TextNode = {
          type: 'Text',
          content: line,
          location: {
            start: locationStart,
            end: { line: lineIndex + 1, column: line.length + 1 }
          }
        };
        nodes.push(textNode);
        lineIndex++;
      }
    }

    return nodes;
  }

  private isCodeFenceStart(line: string): boolean {
    // E.g. line starts with three or more backticks
    return /^```+/.test(line.trim());
  }

  private parseCodeFence(
    lines: string[],
    startLineIndex: number
  ): { node: CodeFenceNode; nextLineIndex: number } {
    // Find matching closing fence
    // Accumulate content lines in between
    // If not found, auto-close at end of file or raise partial parse warnings
    // Return CodeFenceNode + nextLineIndex after fence
  }

  private isDirectiveLine(line: string): boolean {
    // Meld grammar: directives start at line-begin with "@"
    // Possibly check for optional lines: if (line.trim().startsWith('@')) ...
    return line.trim().startsWith('@');
  }

  private parseDirective(line: string, lineIndex: number): DirectiveNode {
    // 1) Extract the directive text
    // 2) Possibly parse out the kind (e.g. "text", "run", "data", etc.)
    // 3) Return a DirectiveNode with .directive = { kind: 'text', ... } plus location
    // 4) If we fail to parse properly, throw MeldParseError
    let kind = '';
    let directiveProps = {};

    // Example: line = "@text greeting = \"Hello\""
    // We'll do a minimal split or more advanced approach
    // for now, we just store the entire line in directiveProps

    const location: Location = {
      start: { line: lineIndex + 1, column: 1 },
      end: { line: lineIndex + 1, column: line.length + 1 }
    };

    return {
      type: 'Directive',
      directive: {
        kind: kind || 'unknown',
        raw: line.trim()
      },
      location
    };
  }
}
--------------------------------------------------------------------------------

This code intentionally does no interpretation. It simply identifies code fences, detects directive lines, everything else is text. Each directive line is stored as a DirectiveNode; the rest is text or code fence. Future expansions can refine parseDirective logic to parse the directive “kind,” arguments, etc.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VII. ISOLATING COMPLEXITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) Keep the Parser Pure
   - It only takes string input, returns MeldNodes[].
   - No reading from disk. No path expansions. No interpreting directives.

2) Simple “Lexer + Parser” Layers (Optional)
   - If the grammar grows large, we can separate out a Lexer that returns tokens, then feed them to a small parser. Right now, a single pass line-based approach might suffice.

3) Minimal Dependencies
   - In the final architecture, no need to inject FileSystemService or StateService. The parser is purely “string in → AST out.”

4) Fine-Grained Helper Methods
   - parseCodeFence, parseDirective, parseComment, parseText, etc.
   - Each method remains easy to test in isolation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIII. TESTING STRATEGY WITHIN OUR TEST ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Our new “services-based” + “Memfs + ProjectBuilder” approach is mostly for integration. The ParserService is simpler: it only needs a string, so typical unit tests might do:

tests/unit/parser/ParserService.test.ts
--------------------------------------------------------------------------------
import { describe, it, expect, beforeEach } from 'vitest';
import { ParserService } from '../../../parser/ParserService';

describe('ParserService', () => {
  let parser: ParserService;

  beforeEach(() => {
    parser = new ParserService(/* config or logger as needed */);
  });

  it('parses a basic @text directive line', () => {
    const input = '@text greeting = "Hello"';
    const result = parser.parseMeld(input);
    expect(result).toHaveLength(1);
    expect(result[0].type).toBe('Directive');
    expect(result[0].location.start.line).toBe(1);
    // ... further checks
  });

  it('handles triple backtick code fence', () => {
    const input = `
\`\`\`typescript
console.log('test');
\`\`\`
    `.trim();
    const ast = parser.parseMeld(input);
    expect(ast).toHaveLength(1); // one code fence
    const node = ast[0];
    expect(node.type).toBe('CodeFence');
    // ...
  });

  it('collects multiple lines of text', () => {
    const input = `Line 1
Line 2
@text directive
Line 3
\`\`\`
code fence
\`\`\``;

    const ast = parser.parseMeld(input);
    // Expect a mixture of TextNodes, DirectiveNode, CodeFenceNode
    // ...
  });

  // Additional negative tests: missing close fence, invalid directive line, etc.
});
--------------------------------------------------------------------------------

• No real file system is needed, because parseMeld only requires a string.  
• For integration tests, we might set up a test that reads an entire fixture from Memfs, passes the fixture content to parser.parseMeld(...), and checks if the AST matches expected.  

In an integration scenario:

tests/integration/interpreter/interpretBasic.test.ts
--------------------------------------------------------------------------------
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { TestContext } from '../../utils/TestContext';
import { ParserService } from '../../../parser/ParserService';
import { readFile } from '../../../services/FileSystemService'; 
// or your in-memory approach

describe('Integration - Parsing a basic doc', () => {
  let context: TestContext;
  let parser: ParserService;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();
    parser = new ParserService();
  });

  afterEach(() => context.cleanup());

  it('parses a doc from the in-mem FS fixture', async () => {
    await context.builder.create({
      files: {
        'project/doc.meld': `
@text greeting = "Hello world"
\`\`\`python
print("test")
\`\`\`
`     }
    });
    // read from the in-mem FS
    const raw = context.fs.readFile('project/doc.meld');
    const ast = parser.parseMeld(raw);

    expect(ast).toHaveLength(2);
    // 0 => DirectiveNode, 1 => CodeFenceNode
  });
});
--------------------------------------------------------------------------------

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IX. HOW DIRECTIVES WILL ULTIMATELY USE IT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) The ParserService is called once the file is read (by FileSystemService or otherwise).  
2) The resulting array of MeldNodes is handed to InterpreterService (or runMeld).  
3) Directives are recognized only by “ParserService” in a broad sense: we see “@import ...,” but we do NOT interpret them. We set Node.type = 'Directive' and directive.kind = 'import' or 'text'.  
4) The DirectiveService and the rest interpret those nodes, do expansions, etc.  

Summary in ASCII:

   ┌───────────────┐
   │ readFile(...) ├───> rawString
   └───────────────┘
           │
           ▼
   ┌─────────────────────┐
   │ ParserService.parse │
   └─────────────────────┘
           │ AST
           ▼
   ┌───────────────────────────┐
   │ InterpreterService.interp │
   └───────────────────────────┘
           │ updates
           ▼
   ┌───────────────────────────┐
   │   StateService / etc      │
   └───────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
X. CONCLUSION & NEXT STEPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The ParserService is a straightforward but vital service. By designing it as a pure “string → AST” step, we isolate all grammar logic from reading/writing files or interpreting directives. We produce MeldNodes with accurate location, supporting advanced error reporting and the rest of the pipeline.

A recommended path to implement and refine:

1) Create ParserService scaffolding: parseMeld(content: string).  
2) Implement line-based approach that handles:  
   - Code fences (triple backticks + optional language)  
   - Directive lines (start with @)  
   - Comments (start with >> )  
   - Normal text otherwise  
3) Produce MeldNodes: { type: 'Directive'|'Text'|'CodeFence', location, content / directive }, with location tracking.  
4) Write thorough unit tests in ParserService.test.ts to handle edge cases, partial code fences, missing directive syntax, etc.  
5) Optionally add a small Lexer if needed and then a Parser step. If the grammar becomes large, consider a formal grammar library.  
6) Provide location data so that the higher-level services can attach errors, e.g. MeldParseError referencing line/col.  
7) Integrate with the broader test architecture, using memory-based files in integration tests, ensuring no path manipulations in the parser tests themselves.  

With this approach, you get a clean, self-contained ParserService that is easy to test, easy to maintain, and well aligned with your passion for SOLID, testable, maintainable architecture.
