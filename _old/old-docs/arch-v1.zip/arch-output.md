# OutputService

Below is a detailed design for the new OutputService, building upon the SOLID architectural principles and test patterns we’ve already established. This service will convert Meld AST (and/or the final interpreter state) into the user’s desired format—most commonly Markdown or “LLM-friendly” XML—while isolating complexity in a clear, testable way.

────────────────────────────────────────────────────────────────────────
I. HIGH-LEVEL ROLE OF THE OUTPUTSERVICE
────────────────────────────────────────────────────────────────────────

The OutputService is the last step in the Meld pipeline:

 1) ParserService → converts Meld text → AST (MeldNode[])
 2) InterpreterService → processes each node, calls DirectiveService, updates StateService
 3) OutputService → takes final AST + state, returns string in the requested format (e.g., 'md' or 'llm')

We thus ensure that all reading/writing to disk, path expansions, directive logic, etc. have already been handled. The OutputService’s sole mission is: “Given the final Meld representation, produce the textual output.”

────────────────────────────────────────────────────────────────────────
II. DESIGN GOALS
────────────────────────────────────────────────────────────────────────

1. Solid Separation Of Concerns  
   - The OutputService focuses exclusively on “AST → output string.”  
   - It doesn’t worry about directive logic, file I/O, path expansions, or variable definitions.

2. Extensible Output Formats  
   - We can easily add new converters (for HTML, JSON, LLM-XML variants, et cetera).  
   - No code bloat in the main service for specialized formats.

3. Straightforward Testing  
   - We will treat OutputService as a normal service with unit tests.  
   - For integration tests, it seamlessly plugs into the test pipeline (parse → interpret → output).

4. Usable By Both CLI & SDK  
   - The CLI calls “runMeld(..., { format: 'md' }),” which eventually calls OutputService.  
   - The SDK does similarly. No duplication or weird bridging code needed.

────────────────────────────────────────────────────────────────────────
III. PROPOSED CODE STRUCTURE
────────────────────────────────────────────────────────────────────────

We add a dedicated folder, matching the “services-based” approach:

services/
 ├─ OutputService/
 │   ├─ OutputService.ts
 │   ├─ OutputService.test.ts
 │   └─ Converters/
 │       ├─ MarkdownConverter.ts
 │       ├─ LLMXmlConverter.ts
 │       └─ (future converters, e.g. HtmlConverter.ts, etc.)
 └─ (...other services)...

To keep it consistent with patterns used in e.g. PathService, StateService, we provide an IOutputService interface, plus a main class implementing it:

--------------------------------------------------------------------------------
// services/OutputService/OutputService.ts
import { MeldNode } from '../../core/types/MeldNode'; 
import { InterpreterState } from '../StateService/InterpreterState';
import { IOutputService, OutputFormat } from './IOutputService';
import { MarkdownConverter } from './Converters/MarkdownConverter';
import { LLMXmlConverter } from './Converters/LLMXmlConverter';

export class OutputService implements IOutputService {
  constructor(
    private mdConverter = new MarkdownConverter(),
    private llmConverter = new LLMXmlConverter()
  ) {}

  public convert(nodes: MeldNode[], state: InterpreterState, format: OutputFormat): string {
    switch (format) {
      case 'md':
        return this.mdConverter.convert(nodes, state);
      case 'llm':
        return this.llmConverter.convert(nodes, state);
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
  }
}
--------------------------------------------------------------------------------

And an interface:

--------------------------------------------------------------------------------
// services/OutputService/IOutputService.ts

import { MeldNode } from '../../core/types/MeldNode';
import { InterpreterState } from '../StateService/InterpreterState';

export type OutputFormat = 'md' | 'llm';

export interface IOutputService {
  convert(nodes: MeldNode[], state: InterpreterState, format: OutputFormat): string;
}
--------------------------------------------------------------------------------

Next, each “converter” is a small class, adopting the same interface shape:

--------------------------------------------------------------------------------
// services/OutputService/Converters/MarkdownConverter.ts

import { MeldNode, TextNode, DirectiveNode } from '../../../core/types/MeldNode';
import { InterpreterState } from '../../StateService/InterpreterState';

export class MarkdownConverter {
  /**
   * Convert the final AST + state to plain Markdown.
   * Some nodes remain verbatim text, code fences remain fenced, etc.
   */
  public convert(nodes: MeldNode[], state: InterpreterState): string {
    const lines: string[] = [];

    for (const node of nodes) {
      if (node.type === 'Text') {
        lines.push((node as TextNode).content);
      } else if (node.type === 'Directive') {
        // Possibly skip or transform certain directives:
        // e.g. Output might omit directives or turn them into comments.
        // Or mark them inline with a special comment.
      }
      // CodeFence etc. if we define them
    }

    // Combine lines with newlines
    return lines.join('\n');
  }
}
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
// services/OutputService/Converters/LLMXmlConverter.ts

import { MeldNode, TextNode, DirectiveNode } from '../../../core/types/MeldNode';
import { InterpreterState } from '../../StateService/InterpreterState';

export class LLMXmlConverter {
  /**
   * Convert AST + state to an “LLM-friendly” XML-like representation
   * with minimal markup, e.g. <section>, <code> tags, etc.
   */
  public convert(nodes: MeldNode[], state: InterpreterState): string {
    let result = '';

    for (const node of nodes) {
      if (node.type === 'Text') {
        // Possibly wrap text in <p> or do minimal escaping
        result += `<text>${(node as TextNode).content}</text>\n`;
      } else if (node.type === 'Directive') {
        // Some directives might become <directive kind="...">
        // Or we might simply skip them. Up to you.
      }
    }

    return result;
  }
}
--------------------------------------------------------------------------------

────────────────────────────────────────────────────────────────────────
IV. ASCII ILLUSTRATION: WHERE OUTPUTSERVICE FITS
────────────────────────────────────────────────────────────────────────

  parse()        interpret()        finalize()
     │                │                 │
     ▼                ▼                 │
┌─────────────┐  ┌───────────────┐     │
│ ParserService│  │InterpreterSvc │     │
└─────────────┘  └───────────────┘     │
                   AST + State          │
                         │             (final step)
                         ▼
                 ┌───────────────────┐
                 │  OutputService    |
                 │   + Converters    |
                 └───────────────────┘
                            │
                            ▼
                    "md" or "llm" string
────────────────────────────────────────────────────────────────────────

────────────────────────────────────────────────────────────────────────
V. ISOLATING COMPLEXITY
────────────────────────────────────────────────────────────────────────

1. Single Purpose Methods  
   - Each converter class does one thing: convert AST + state to string. That’s it.  
   - We never let them mutate states or do file I/O.

2. Pluggable Converter Classes  
   - The main OutputService picks the converter based on the requested format.  
   - If we add new formats, we add a new converter class in /Converters, no disruptions to the existing code.

3. Node-Specific Logic Encapsulated  
   - E.g. if we want special logic for code fences, we place it in e.g. “renderCodeFence(node: CodeFenceNode)” (a private method).  
   - The rest of the code remains tidy.

4. Keep Directives Out-of-Scope at Final Output  
   - Typically, once directives are processed, the final “pure text” or “text nodes” remain.  
   - If a directive wants to produce special textual markers in the final doc, it sets that up in the AST. The OutputService just sees normal nodes.

────────────────────────────────────────────────────────────────────────
VI. PATTERNS FOR USING OUTPUTSERVICE
────────────────────────────────────────────────────────────────────────

Although directives themselves usually do not call OutputService, let’s illustrate how the pipeline calls it:

(1) The user calls “runMeld('doc.meld', { format: 'md' })”.  
(2) Inside runMeld:  
    1) parse → AST  
    2) interpret → modifies State, potentially modifies or finalizes AST  
    3) OutputService.convert(AST, state, 'md')  
       → returns a string

If a hypothetical directive wanted to generate partial “previews,” it might do:

--------------------------------------------------------------------------------
// Some hypothetical scenario:
const partialNodes = directiveHandler.produceIntermediateAst(...);
const snippet = outputService.convert(partialNodes, currentState, 'md');
return snippet;
--------------------------------------------------------------------------------

But that’s less common.

────────────────────────────────────────────────────────────────────────
VII. TESTING STRATEGY ALIGNED WITH OUR TEST ARCHITECTURE
────────────────────────────────────────────────────────────────────────

We develop the OutputService tests in two layers: 
1) A unit test verifying each converter individually.  
2) Integration tests verifying the entire pipeline from parse → interpret → output.  

A. Unit Testing (services/OutputService/OutputService.test.ts, plus per-converter tests)
--------------------------------------------------------------------------------
// services/OutputService/OutputService.test.ts
import { describe, it, expect, beforeEach } from 'vitest';
import { OutputService } from './OutputService';
import { MarkdownConverter } from './Converters/MarkdownConverter';
import { LLMXmlConverter } from './Converters/LLMXmlConverter';
import { MeldNode } from '../../core/types/MeldNode';
import { InterpreterState } from '../StateService/InterpreterState';
import { TestContext } from '../../../tests/utils/TestContext';  // If needed

describe('OutputService - unit', () => {
  let outputService: OutputService;
  let mockMd: MarkdownConverter;
  let mockLlm: LLMXmlConverter;

  beforeEach(() => {
    mockMd = new MarkdownConverter();
    mockLlm = new LLMXmlConverter();
    outputService = new OutputService(mockMd, mockLlm);
  });

  it('selects markdown converter', () => {
    const nodes: MeldNode[] = [{ type: 'Text', content: 'Hello', location: {...} }];
    const state = new InterpreterState();
    const result = outputService.convert(nodes, state, 'md');
    // By default we expect the MarkdownConverter method was called
    // Check result, or spy on mockMd.convert
  });

  it('selects LLM converter', () => {
    // Similar test
  });

  it('rejects unknown format', () => {
    expect(() => outputService.convert([], new InterpreterState(), 'unknown' as any))
      .toThrow('Unsupported format');
  });
});
--------------------------------------------------------------------------------

Then for each converter, we can do a narrower test:

--------------------------------------------------------------------------------
// services/OutputService/Converters/MarkdownConverter.test.ts
import { describe, it, expect } from 'vitest';
import { MarkdownConverter } from './MarkdownConverter';
import { MeldNode } from '../../../core/types/MeldNode';
import { InterpreterState } from '../../StateService/InterpreterState';

describe('MarkdownConverter - unit', () => {
  it('handles basic text nodes', () => {
    const converter = new MarkdownConverter();
    const nodes: MeldNode[] = [
      { type: 'Text', content: 'Hello World', location: { ... } },
    ];
    const st = new InterpreterState();
    const out = converter.convert(nodes, st);
    expect(out).toBe('Hello World');
  });

  it('skips directive nodes, or transforms them, etc.', () => {
    // ...
  });
});
--------------------------------------------------------------------------------

B. Integration Testing (tests/integration/…)
--------------------------------------------------------------------------------
import { describe, it, expect } from 'vitest';
import { runMeld } from '../../../sdk';
import { TestContext } from '../../utils/TestContext';

describe('OutputService Integration - md & llm', () => {
  let context: TestContext;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();
  });
  afterEach(() => context.cleanup());

  it('converts a simple doc to markdown', async () => {
    // 1) Create a doc with a text node
    context.builder.create({
      files: {
        'doc.meld': '@text greeting = "Hello"'
      }
    });
    // 2) Run meld with format=md
    const result = await runMeld('doc.meld', { format: 'md' });
    // 3) We expect the output to contain "Hello"
    expect(result).toContain('Hello');
  });

  it('converts a doc to llm format', async () => {
    // Similar approach, specifying format=llm
  });
});
--------------------------------------------------------------------------------

Thus, we thoroughly test each converter in isolation and confirm the entire pipeline works seamlessly.

────────────────────────────────────────────────────────────────────────
VIII. FURTHER NOTES & EXTENSIONS
────────────────────────────────────────────────────────────────────────

• Code Fences Handling:  
  If the AST includes a node type { type: 'CodeFence', content, language }, then each converter can have a small method to properly wrap code blocks in backticks or <code> tags.  

• Escaping:  
  The LLM XML converter might do minimal escaping on <, >, &. The Markdown converter might do minimal or no escaping.  

• Additional Output Formats:  
  We could add JSON or HTML just by writing AnotherConverter.ts and hooking it into OutputService.  

• Handling Large Documents:  
  Performance is typically not a priority before correctness. Our approach—transforming the nodes one by one—is fine for most real-world docs. If we needed partial transformations or streaming, we could adapt the code to yield piecewise.  

────────────────────────────────────────────────────────────────────────
IX. CONCLUSION
────────────────────────────────────────────────────────────────────────

By structuring the OutputService around a single “convert(AST, state, format)” method and specialized converter classes, we keep it easy to maintain, test, and extend. The service itself is minimal logic—just picks which converter to invoke—and each converter focuses purely on generating the final textual representation of the already-interpreted Meld content.

In combination with the test architecture (TestContext, MemfsTestFileSystem, fixture-based integration tests), we ensure that we can thoroughly verify each converter’s correctness and the entire pipeline from parse → interpret → output. This design is fully SOLID, lines up with the Meld grammar (simply rendering final nodes), and is ready for future expansions with minimal friction.
