Below is a consolidated punch-list covering each major aspect of the proposed architecture (Parser, Interpreter, Directives, State, Path/FileSystem, Validation, Interpolation, Output) and how we should adjust or refactor the existing code/documentation to fully align with the new SOLID “services-based” design and the insights from all newly provided materials.

────────────────────────────────────────────────────────────────────────
1) OVERALL PROJECT STRUCTURE & CODE ORGANIZATION
────────────────────────────────────────────────────────────────────────
• Create a “services/” folder (or equivalent) with subfolders for each major service:  
  – PathService/  
  – FileSystemService/  
  – CircularityService/ (optional, if we separate it)  
  – ValidationService/  
  – StateService/  
  – DirectiveService/  
  – InterpolationService/  
  – InterpreterService/  
  – OutputService/  

• Move each relevant piece of logic and data (currently scattered across “fs.ts,” “cli.test.ts,” “index.ts,” etc.) into these dedicated service folders.  
• Eliminate direct references to Node’s fs or path in directive code; those references should go through FileSystemService and PathService instead.  
• Keep meld-ast, meld-spec, or llmxml references only if truly needed. For instance, “meld-ast” can remain the underlying parser or be replaced by a new ParserService.  
• Ensure that the existing “__mocks__” or “fs-extra” stubs are replaced by the new FileSystemService approach wherever feasible.

────────────────────────────────────────────────────────────────────────
2) PARSER & “PARSER SERVICE”
────────────────────────────────────────────────────────────────────────
• Rename or reorganize “parser.ts” into a “ParserService” that returns a clean AST (MeldNode[]).  
• Remove code that directly references “meld-ast” or raw tokenization if we intend to keep that library. Either:  
  – Wrap the meld-ast parse function in our ParserService class.  
  – Or keep the custom logic but place it in a new services/ParserService/ParserService.ts.  
• Maintain accurate location data during parsing for all nodes.  
• Provide a small set of unit tests for “ParserService,” ensuring normal and error conditions.

────────────────────────────────────────────────────────────────────────
3) INTERPRETER SERVICE
────────────────────────────────────────────────────────────────────────
• Extract the current interpret() logic (in “interpreter.ts,” “cmd.ts,” or “index.ts”) into a “services/InterpreterService/InterpreterService.ts.”  
• Ensure it loops over AST nodes, calls DirectiveService for directive nodes, and either does nothing (or minimal handling) for text/code-fence nodes.  
• Remove any direct references to file I/O or path expansions from this interpreter code—delegate that to directive handlers (which in turn call Path/FileSystem).  
• If sub-interpretation is needed (e.g. in @import), let the import directive call “interpreterService.interpret(subAST, childState).”  
• Provide unit tests that mock DirectiveService and StateService for quick coverage, plus integration tests in the new test structure.

────────────────────────────────────────────────────────────────────────
4) DIRECTIVE SERVICE & INDIVIDUAL HANDLERS
────────────────────────────────────────────────────────────────────────
• Create a “DirectiveService,” which registers/locates directive handlers by “kind” (text, data, import, embed, define, etc.).  
• In the “handlers/” subfolder, give each directive kind its own class or function (e.g., “TextDirectiveHandler,” “ImportDirectiveHandler,” “EmbedDirectiveHandler,” etc.).  
• Each handler should:  
  – Call ValidationService first for grammar checks.  
  – Use InterpolationService if needed (e.g. to expand “${vars}”).  
  – Possibly call PathService/FileSystemService for I/O.  
  – Then update StateService with final results.  
• Remove logic scattered across “cli.test.ts,” “fs.ts,” “index.ts,” or “parser.ts” that interprets directives, and place it in these dedicated handlers.

────────────────────────────────────────────────────────────────────────
5) STATE SERVICE
────────────────────────────────────────────────────────────────────────
• Convert the existing “InterpreterState” class (currently in “state.ts”) into a dedicated “StateService” (services/StateService/StateService.ts) that:  
  – Provides clear get/set methods for text variables, data variables, path variables, commands, etc.  
  – Supports createChildState() plus mergeChildState(child).  
  – Tracks imports or “circular references” flags if needed (or delegates to CircularityService).  
  – Allows optional setImmutable() to freeze.  
• Update all directive or interpreter references to stop storing variables arbitrarily; they must go through StateService.  
• Write dedicated unit tests for all set/get/merge paths, verifying collisions, immutability, and scoping.

────────────────────────────────────────────────────────────────────────
6) VALIDATION SERVICE
────────────────────────────────────────────────────────────────────────
• Create a “ValidationService” that has a “validateDirective(directiveNode)” method.  
• Offload directive-grammar checks (like “@text requires name,” “@import needs path,” etc.) into sub-files under “directiveValidators/.”  
• In each directive handler, call validationService.validateDirective(node) at the start.  
• Provide thorough unit tests with contrived DirectiveNodes for each directive kind, ensuring we throw typed MeldErrors for invalid shapes.  
• Remove any scattered “if (!directive.name) throw …” checks from handlers—move that logic to the new ValidationService.

────────────────────────────────────────────────────────────────────────
7) INTERPOLATION SERVICE
────────────────────────────────────────────────────────────────────────
• Extract all “${var},” “#{data.field},” or “$pathVar” expansions from directives into a dedicated “InterpolationService.”  
• Provide a method like “resolveString(str, context)” that:  
  – Identifies expansions (text vs data vs path).  
  – Looks up variables via StateService, or calls PathService when needed.  
  – (Optionally) calls a FormatService for “>>(format)” operations if that’s desired.  
• Replace any inline expansions in the code with calls like interpolationService.resolveString(…).  
• Provide unit tests that feed in example strings with expansions; check that we get correct final strings for normal and error scenarios (missing var, etc.).

────────────────────────────────────────────────────────────────────────
8) PATH SERVICE
────────────────────────────────────────────────────────────────────────
• Move path expansions and special references ($PROJECTPATH, $HOMEPATH, $~/, $./) into a dedicated “PathService.”  
• Remove direct “path” or “process.cwd()” logic from directive handlers or other code. All expansions must go through pathService.resolvePath(...).  
• Provide “enableTestMode(homeOverride, projectOverride)” for in-memory or test usage.  
• Thoroughly test “resolvePath(…)” with all special prefixes, rejecting “..” or others per the design.  
• Eliminate the scattered references to “mock path” in “fs.ts,” using the new PathService approach in test contexts.

────────────────────────────────────────────────────────────────────────
9) FILE SYSTEM SERVICE
────────────────────────────────────────────────────────────────────────
• Create a “FileSystemService” (services/FileSystemService/FileSystemService.ts) that:  
  – Has readFile, writeFile, exists, ensureDir, etc.  
  – In production, uses Node’s fs/promises. In test mode, uses an in-memory or mock adapter.  
• Remove the direct usage of “fs,” “fs/promises,” or “fs-extra” from code; all directives or other services should go through FileSystemService.  
• Adopt typed MeldFileSystemError for consistent file-related error handling.  
• Provide unit tests that confirm read/write behavior for typical success/failure scenarios.

────────────────────────────────────────────────────────────────────────
10) OUTPUT SERVICE
────────────────────────────────────────────────────────────────────────
• Introduce an “OutputService” that can transform the final AST + state to either Markdown or LLM-friendly XML (or other formats).  
• Keep specialized logic in sub-classes or sub-files (MarkdownConverter, LLMXmlConverter, …).  
• The “runMeld” flow or CLI can then do: outputService.convert( ast, state, format ), yielding the final string.  
• Move code from “converter.ts,” “llmxml-utils.ts,” or “converter.md” documentation into this new OutputService approach.  
• Confirm in integration tests that parse → interpret → output yields correct markdown or LLM XML.

────────────────────────────────────────────────────────────────────────
11) CLI HOOKS & SDK “runMeld”
────────────────────────────────────────────────────────────────────────
• In “cli/cmd.ts” or “sdk/index.ts,” orchestrate:  
  -> Parse with ParserService.  
  -> Interpret with InterpreterService.  
  -> Output with OutputService.  
  – Possibly handle file reading with FileSystemService for the input, and write results similarly.  
• Remove any leftover logic that does direct AST manipulation or path expansions in the CLI if that belongs in directive or interpolation.  
• Expose extended options for formats, user-specified “md” or “llm,” etc.

────────────────────────────────────────────────────────────────────────
12) TESTING INFRASTRUCTURE (UNIT vs INTEGRATION)
────────────────────────────────────────────────────────────────────────
• For each service subfolder (PathService, FileSystemService, StateService, etc.), add unit tests that mock or stub out external calls.  
• Create new “tests/integration/…” directories for multi-step flows (embedding a file, importing sub-docs, etc.).  
• Confirm all old references to “fs,” “path,” or raw environment variables are replaced by calls to PathService and FileSystemService in directive tests.  
• Use the Memfs or in-memory approach for all integration tests, as described in the “TestFileSystem / ProjectBuilder / TestContext” design, so no real path manipulation is needed in test code.  
• Summarily remove ad-hoc mocking (like “fs-extra.ts,” “fs-promises.ts,” etc.) if they’re fully supplanted by the new FileSystemService approach.

────────────────────────────────────────────────────────────────────────
13) REMOVING OR RE-ASSIGNING LEGACY CODE
────────────────────────────────────────────────────────────────────────
• “meld.ts,” “fs.ts,” “fs-extra.ts,” “fs-promises.ts,” etc. that attempt partial mocking or direct path usage can be removed or drastically reduced to shells that likewise delegate to the new services.  
• “meld-ast.ts,” “llmxml-utils.ts,” or “meld-spec” references can remain if they still conform to the new architecture. Otherwise, phase them out or wrap them in our new services if needed.  
• Merge any lingering partial code repeated in these modules into the new classes or remove them if they’re superseded.

────────────────────────────────────────────────────────────────────────
14) SHIFTING DIRECTIVES TOWARD FULL “SERVICE USAGE”
────────────────────────────────────────────────────────────────────────
• Revisit each directive: @text, @data, @path, @embed, @import, @define, @run, etc.  
• Ensure each one has a dedicated “XDirectiveHandler.”  
• Make sure each handler calls:  
  (a) validationService.validateDirective(node)  
  (b) interpolationService.resolveString(...) if needed  
  (c) pathService/fileSystemService if file logic is needed  
  (d) stateService for storing final variables or for merges.  
• Refactor or remove any leftover code in “interpreter.ts,” “parser.ts,” or anywhere else that attempts directive logic.

────────────────────────────────────────────────────────────────────────
15) DOCUMENTATION & CLEANUP
────────────────────────────────────────────────────────────────────────
• Update or rewrite “CONVERTER.md,” “INTERPRETER.md,” “CLI.md” to reflect the new services approach.  
• Provide short README files in each service folder (PathService, FileSystemService, etc.) clarifying responsibilities and usage with code examples.  
• Clean up references to “meld-ast,” “llmxml,” or partial older doc stubs if we no longer need them or if we rewrapped them in the new approach.  
• Summarize the final directory structure in the top-level README to guide future devs.

────────────────────────────────────────────────────────────────────────

By systematically executing these changes, we will have a fully reconciled, SOLID, service-based Meld implementation that:  
• Strictly matches the Meld grammar and the newly provided architecture.  
• Consolidates and reorganizes existing code into distinct services with clear boundaries.  
• Simplifies testing through separation of concerns and a consistent “test context” or “memfs” approach.  
• Eliminates direct path or file references in directives, preserving them for PathService/FileSystemService.  

This holistic refactoring ensures long-term maintainability, clarity, and compliance with the updated design documents.
