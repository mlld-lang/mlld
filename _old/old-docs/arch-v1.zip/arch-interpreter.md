# InterpreterService

Below is a proposed design for the InterpreterService, illustrating its responsibilities, interactions, and how we will organize and test it within the new architecture. This design is specific and follows the SOLID, services-based approach set out previously, including how it aligns with the Meld grammar and target UX.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
I. OVERVIEW & POSITION IN THE ARCHITECTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) The InterpreterService is responsible for orchestrating the high-level “interpretation” phase of Meld documents.  
2) It processes an AST (parsed by ParserService), identifies directive nodes, routes them to DirectiveService, and ensures the final state is merged into StateService.  
3) It does NOT handle I/O directly (FileSystemService does that), does NOT expand paths (PathService does that), and does NOT do final output formatting (OutputService does that). It focuses purely on “given an AST of MeldNodes, produce the final interpreted state (variables, replaced sections, etc.).”

Here’s how it fits into the previously proposed flow:

┌──────────────────────────────────┐  
│ ParserService (generates AST)   │  
└─────────────┬───────────────────┘  
              │ MeldNode[]  
              ▼  
┌─────────────────────────────────────────────────────┐  
│          InterpreterService (focus of this doc)     │  
│  • Iterates AST nodes                               │  
│  • For each directive, calls DirectiveService       │  
│  • Merges changes into StateService                 │  
└─────────────┬───────────────────────────────────────┘  
              ▼ updated variables, embedded content  
┌─────────────────────────────────────────────────────┐  
│        Next steps: (OutputService / final usage)    │  
└─────────────────────────────────────────────────────┘  

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
II. FILE & CLASS STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

A recommended place for the InterpreterService:

services/  
  ├─ InterpreterService/  
  │   ├─ InterpreterService.ts  
  │   ├─ InterpreterService.test.ts  
  │   └─ (any sub-files if we want private helpers)  

Inside InterpreterService.ts, we will define:

1) An IInterpreterService interface (optional but recommended)  
2) A concrete InterpreterService class that implements that interface  
3) Possibly some small helper private methods (like handleTextNode, handleDirectiveNode, etc.)  

Below is an outline of the code structure:

─────────────────────────────────────────────────────────────────────────
InterpreterService.ts
─────────────────────────────────────────────────────────────────────────
import { MeldNode, DirectiveNode, TextNode } from '../../core/types/MeldNode';
import { IDirectiveService } from '../DirectiveService/DirectiveService';
import { IStateService } from '../StateService/StateService';
import { MeldInterpretError } from '../../core/errors/MeldError';

export interface IInterpreterService {
  interpret(nodes: MeldNode[]): Promise<void>;  
}

export class InterpreterService implements IInterpreterService {
  constructor(
    private readonly directiveService: IDirectiveService,
    private readonly stateService: IStateService
  ) {}

  public async interpret(nodes: MeldNode[]): Promise<void> {
    for (const node of nodes) {
      await this.handleNode(node);
    }
  }

  private async handleNode(node: MeldNode): Promise<void> {
    switch (node.type) {
      case 'Text':
        // Potentially store raw text in the state, or do something else
        this.handleTextNode(node);
        break;
      case 'Directive':
        await this.handleDirectiveNode(node);
        break;
      default:
        throw new MeldInterpretError(`Unknown node type: ${node.type}`);
    }
  }

  private handleTextNode(node: TextNode) {
    // Potentially store or track literal text lines, or do nothing
    // For many Meld flows, raw text lines remain as-is to be re-output.
    // Possibly we do:
    this.stateService.addTextNode(node);
  }

  private async handleDirectiveNode(node: DirectiveNode) {
    // Defer to the directive service
    await this.directiveService.execute(node, this.stateService);
  }
}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
III. DEPENDENCIES & ISOLATION STRATEGY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) DirectiveService  
   - The InterpreterService does NOT itself interpret each directive’s arguments or do filesystem I/O.  
   - It only calls directiveService.execute(node, stateService).  

2) StateService  
   - The InterpreterService holds a reference to StateService (or obtains it from a higher-level context) so that it can pass the same shared state around.  
   - Typically, each directive modifies that same StateService with variables, data, paths, etc.  

3) No direct references to PathService or FileSystemService  
   - That is the directive’s concern.  
   - This ensures the InterpreterService remains lean and decoupled.  

4) Generic error throwing with MeldInterpretError  
   - If we see unknown node types or other anomalies, we throw an interpret-level error.  
   - For directive-specific issues, directive handlers throw MeldDirectiveError, MeldEmbedError, etc.  

This design ensures that each piece is testable. The entire pipeline is tested in integration tests, but if the directive logic fails, it’s the directive’s fault.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IV. FLOW DETAIL (ASCII ILLUSTRATION)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Here’s a short ASCII diagram of the interpret process:

   interpret(nodes) ──────────────────────────────────────┐
                  for(each node)                         │
                     ▼                                    │
            ┌─────────────────────────┐                   │
            │   node.type === 'Text'  │                   │
            └─────────────────────────┘                   │
                     ▼ else if (Directive)                │
   ┌───────────────────────────────────────────────────┐   │
   │ directiveService.execute(node, stateService)      │   │
   └───────────────────────────────────────────────────┘   │
                     ▼ (updates state)                    │
   ┌───────────────────────────────────────────────────┐   │
   │ stateService merges changes, sets variables, etc.│   │
   └───────────────────────────────────────────────────┘   │
                     ▼ loop next node                    │
   (end) ─────────────────────────────────────────────────┘


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
V. DIRECTIVE HANDLERS EXAMPLE PATTERN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Inside DirectiveService, we have something like:

─────────────────────────────────────────────────────────────────────────
export class DirectiveService implements IDirectiveService {
  constructor(
    private validationService: IValidationService,
    private handlers: { [kind: string]: IDirectiveHandler }
  ) {}

  public async execute(directiveNode: DirectiveNode, state: IStateService): Promise<void> {
    const handler = this.handlers[directiveNode.directive.kind];
    if (!handler) {
      throw new MeldInterpretError(`No handler for directive kind: ${directiveNode.directive.kind}`);
    }
    await handler.execute(directiveNode, state);
  }
}
─────────────────────────────────────────────────────────────────────────

So the InterpreterService calls directiveService.execute(...) for each directive node.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VI. HOW DIRECTIVES WILL USE THE INTERPRETER (OR VICE VERSA)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• The directive does NOT “call the interpreter” directly; it just runs its logic.  
• The interpreter is in charge of “stepping through” each node.  
• If a directive spawns a sub-interpretation (like a nested .meld import), that directive might create a new child StateService or call the interpreter recursively. But that is done inside, e.g., “ImportDirectiveHandler”:

    // pseudo-code
    class ImportDirectiveHandler {
      async execute(node, state) {
        // 1) parse the file -> new AST
        // 2) create a child state or ask circularityService
        // 3) call interpreterService.interpret(subAst) with child state
        // 4) later merges child state into parent
      }
    }

This keeps the main “interpret” flow as a single pass, deferring sub-ast logic to directives that require it (like import or embed).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VII. TESTING STRATEGY & PATTERNS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

We will follow the new test architecture. Specifically:

1) Unit Tests in services/InterpreterService/InterpreterService.test.ts  
   - We give it a mock DirectiveService and a mock StateService.  
   - Provide a small set of MeldNodes, ensure interpret() does the right calls.  

2) Integration Tests in tests/integration/interpreter/  
   - We stand up a real DirectiveService with real directive handlers, a real StateService, a MemfsTestFileSystem, etc.  
   - Then parse an actual file with ParserService -> get AST.  
   - Then call “new InterpreterService(directiveService, stateService).interpret(ast).”  
   - Check final state or final output.  

Example: “InterpreterService.test.ts” (UNIT)

─────────────────────────────────────────────────────────────────────────
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { InterpreterService } from './InterpreterService';
import { DirectiveNode, TextNode } from '../../core/types/MeldNode';

describe('InterpreterService (unit)', () => {
  let directiveServiceMock: any;
  let stateServiceMock: any;
  let interpreter: InterpreterService;

  beforeEach(() => {
    directiveServiceMock = { execute: vi.fn() };
    stateServiceMock = { addTextNode: vi.fn() };
    interpreter = new InterpreterService(directiveServiceMock, stateServiceMock);
  });

  it('handles text nodes by calling stateService.addTextNode', async () => {
    const textNode: TextNode = {
      type: 'Text',
      content: 'Hello!',
      location: { start: { line:1, column:1 }, end: { line:1, column:7 } }
    };
    await interpreter.interpret([textNode]);
    expect(stateServiceMock.addTextNode).toHaveBeenCalledWith(textNode);
  });

  it('handles directive nodes by calling directiveService.execute', async () => {
    const directiveNode: DirectiveNode = {
      type: 'Directive',
      directive: { kind: 'text', name: 'greeting', value: 'Hello' },
      location: { start: { line:1, column:1}, end: { line:1, column:10} }
    };
    await interpreter.interpret([directiveNode]);
    expect(directiveServiceMock.execute).toHaveBeenCalledWith(directiveNode, stateServiceMock);
  });

  it('throws error on unknown node type', async () => {
    const weirdNode = { type: 'Weird' } as any;
    await expect(interpreter.interpret([weirdNode])).rejects.toThrow('Unknown node type');
  });
});
─────────────────────────────────────────────────────────────────────────

Then an Integration Test example in “tests/integration/interpreter/interpretSimple.test.ts”:

─────────────────────────────────────────────────────────────────────────
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { TestContext } from '../../utils/TestContext'; 
import { parseMeld } from '../../../parser/ParserService';
import { InterpreterService } from '../../../services/InterpreterService/InterpreterService';
import { DirectiveService } from '../../../services/DirectiveService/DirectiveService';
import { createAllDefaultHandlers } from '../../../services/DirectiveService/handlers';
import { StateService } from '../../../services/StateService/StateService';

describe('InterpreterService (integration) - basic doc', () => {
  let context: TestContext;
  let interpreter: InterpreterService;
  let directiveService: DirectiveService;
  let stateService: StateService;

  beforeEach(() => {
    context = new TestContext();
    context.initialize();

    // Build a minimal project
    context.builder.create({
      files: {
        'doc.meld': `
          @text greeting = "Hello!"
          Some plain text line
        `
      }
    });

    // Create the real services
    stateService = new StateService();
    directiveService = new DirectiveService(/* pass other services, plus our directive handlers */);
    interpreter = new InterpreterService(directiveService, stateService);
  });

  afterEach(() => context.cleanup());

  it('interprets a doc with a text directive + raw text lines', async () => {
    // 1) parse the file
    const content = context.fs.readFile('doc.meld');
    const ast = parseMeld(content);

    // 2) interpret
    await interpreter.interpret(ast);

    // 3) assert
    expect(stateService.getTextVar('greeting')).toBe('Hello!');
    // Possibly we also store the raw text lines in state...
    // or check final output in a separate step
  });
});
─────────────────────────────────────────────────────────────────────────

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIII. EXTENDING THE INTERPRETER FOR SUB-INTERPRETATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

As soon as we add “@import” or “@embed” with nested interpretation, we can add:

class ImportDirectiveHandler {
  constructor(
    private parserService: IParserService,
    private interpreterService: IInterpreterService,
    private fileSystemService: IFileSystemService,
    private circularityService: ICircularityService,
  ) {}

  async execute(node: DirectiveNode, state: IStateService): Promise<void> {
    const importPath = node.directive.path;
    // check for circular reference
    this.circularityService.beginImport(importPath);
    const fileContent = await this.fileSystemService.readFile(importPath);
    const subAst = this.parserService.parse(fileContent);

    // create a child state or something
    const childState = state.createChild();
    await this.interpreterService.interpret(subAst);

    // merge childState back
    state.mergeChild(childState);
  }
}

This approach places sub-interpretation fully in the directive logic, keeping the main InterpreterService code extremely simple.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IX. WHY THIS DESIGN?
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• The InterpreterService remains the central loop that processes nodes.  
• Each directive’s complexity is hidden in its own handler.  
• We can test the entire pipeline in an integration test or test each directive handler in isolation.  
• The code is short, easy to read, and obviously correct.  
• We abide by SOLID principles: single responsibility for the interpreter, no massive class with 1,000 lines of logic.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
X. SUMMARY & KEY TAKEAWAYS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) The InterpreterService is small—just a loop over AST nodes, calling an appropriate method for each.  
2) Each directive is handled by the DirectiveService (and sub-handlers).  
3) State is updated in the StateService.  
4) We isolate complexities (file I/O, path expansions, sub-interpretation) in their own services so the interpreter is as minimal as possible.  
5) Our testing approach uses an in-memory file system, a declared project structure, and a “TestContext” to keep the code free of ephemeral path manipulation.  
6) We thoroughly unit-test the interpreter’s logic with mocks for directiveService and stateService, and do integration tests that spin up real directive handlers.

The result is an InterpreterService design that is easy to reason about, easy to test at multiple levels, and that slots neatly into the larger Meld architecture and test harness. This is the foundation for the codebase we want: SOLID, maintainable, and user-friendly in production and in ongoing development.
