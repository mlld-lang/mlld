Below is a proposed “services-based” architecture that embraces SOLID principles, fully aligns with the Meld spec, and keeps complexity well-isolated. This design aims to be more testable, readable, and maintainable, and sets a strong foundation for future expansions, while fully conforming to the Meld UX and grammar requirements.

─────────────────────────────────────────────────────────────────────────
  OVERVIEW & KEY GOALS
─────────────────────────────────────────────────────────────────────────

1. Strictly honor the Meld GRAMMAR and UX Spec.  
2. Fully isolate complex features behind discrete “Services.”  
3. Make each directive’s logic self-contained, tested, and easy to augment.  
4. Provide a clear path for future expansions (circular import detection, advanced validations, environment variables, etc.).  
5. Prioritize readability, maintainability, correctness over performance.  

─────────────────────────────────────────────────────────────────────────
  HIGH-LEVEL FLOW
─────────────────────────────────────────────────────────────────────────

A typical Meld usage scenario:

   ┌─────────────────────────────────────┐
   │         Input Meld Document        │
   │   (myfile.meld or similar)         │
   └─────────────────────────────────────┘
                    │
                    ▼
   ┌─────────────────────────────────────┐
   │ ParserService: Parse text into AST │
   └─────────────────────────────────────┘
                    │ AST (MeldNode[])
                    ▼
   ┌────────────────────────────────────────────────────┐
   │ InterpreterService: For each node, route to       │
   │   the DirectiveService & supporting services      │
   └────────────────────────────────────────────────────┘
                    │
                    ▼ updates
   ┌─────────────────────────────────────────────────────┐
   │ StateService: Holds all variable/data state,       │
   │   merges changes from directives, etc.             │
   └─────────────────────────────────────────────────────┘
                    │
                    ▼
   ┌─────────────────────────────────────────────────────┐
   │ OutputService: Converts final state/AST to desired  │
   │   format (markdown, llm XML, or others)             │
   └─────────────────────────────────────────────────────┘

─────────────────────────────────────────────────────────────────────────
  CODEBASE STRUCTURE
─────────────────────────────────────────────────────────────────────────

A recommended directory layout with multiple services, each handling a discrete concern.

  
project-root/
├─ core/
│  ├─ errors/
│  │  ├─ MeldError.ts         # Base custom error classes
│  │  └─ ErrorFactory.ts      # Central creation for typed errors
│  ├─ types/
│  │  ├─ MeldNode.ts          # AST definitions (DirectiveNode, TextNode...)
│  │  └─ SpecInterfaces.ts    # Detailed interfaces from grammar
│  └─ utils/
│     ├─ logger.ts            # Winston or other logging
│     └─ helpers.ts           # Common small utilities
├─ services/
│  ├─ PathService/
│  │  ├─ PathService.ts       # Handling $PROJECTPATH, $HOMEPATH, expansions
│  │  └─ PathService.test.ts  # Unit tests
│  ├─ FileSystemService/
│  │  ├─ FileSystemService.ts # Abstract read/write to disk, mocking
│  │  └─ ...
│  ├─ CircularityService/
│  │  ├─ CircularityService.ts # Tracks imports, detects cycles
│  │  └─ ...
│  ├─ ValidationService/
│  │  ├─ ValidationService.ts  # Directive syntax & argument checks
│  │  └─ ...
│  ├─ StateService/
│  │  ├─ StateService.ts       # Manages variables, merges child states
│  │  └─ ...
│  ├─ InterpolationService/
│  │  ├─ InterpolationService.ts # “${var}”, “#{data}”, handling
│  │  └─ ...
│  ├─ DirectiveService/
│  │  ├─ DirectiveService.ts   # Orchestrates directive handlers
│  │  ├─ handlers/
│  │  │  ├─ TextDirectiveHandler.ts
│  │  │  ├─ DataDirectiveHandler.ts
│  │  │  ├─ EmbedDirectiveHandler.ts
│  │  │  ├─ ImportDirectiveHandler.ts
│  │  │  ├─ PathDirectiveHandler.ts
│  │  │  └─ ...
│  │  └─ ...
│  └─ ...
├─ parser/
│  ├─ ParserService.ts       # Implementation of Meld parser from grammar
│  └─ ...
├─ interpreter/
│  ├─ InterpreterService.ts  # The top-level “interpret” logic
│  └─ ...
├─ output/
│  ├─ OutputService.ts       # toMarkdown, toLLM, etc
│  └─ ...
├─ tests/
│  ├─ integration/
│  │  ├─ cli.test.ts
│  │  ├─ sdk.test.ts
│  │  └─ ...
│  ├─ unit/
│  │  └─ (unit tests for each service)
│  └─ ...
├─ cli/
│  ├─ cmd.ts                 # Command entry
│  └─ ...
├─ sdk/
│  ├─ index.ts               # runMeld, parseMeld, ...
│  └─ ...
└─ package.json

─────────────────────────────────────────────────────────────────────────
  SERVICE ARCHITECTURE DETAILS
─────────────────────────────────────────────────────────────────────────

Below is a breakdown of key services, their responsibilities, and how they interrelate.

─────────────────────────────────────────────────────────────────────────
  1. PathService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Expand special path variables ($PROJECTPATH, $HOMEPATH, etc.)  
  - Normalize path on each platform (POSIX/Win32)  
  - Provide test-mode overrides for easy mocking  

• Example Usage in a directive:  
  "PathDirectiveHandler" calls PathService.resolve("$PROJECTPATH/foo.txt")  
  -> returns /my/project/foo.txt  

─────────────────────────────────────────────────────────────────────────
  2. FileSystemService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Abstract raw file operations (read, write, exist checks)  
  - Provide uniform mocking approach for tests  
  - Handle error codes, e.g. ENOENT -> MeldError  

• Example:  
  "ImportDirectiveHandler" needs to read a .meld file from disk:  
     fileSystemService.readFile(resolvedPath)  

─────────────────────────────────────────────────────────────────────────
  3. CircularityService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Keep track of which files have been imported  
  - Detect cycles (File A imports B, B imports A, etc.)  
  - Provide user-friendly error if a cycle is found  

• Example:  
  "ImportDirectiveHandler" notifies CircularityService.importStarted(filePath),  
  then if importStarted returns an error, we throw a “Circular reference” MeldError.  

─────────────────────────────────────────────────────────────────────────
  4. StateService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Store and retrieve Meld variables: text, path, data, define, etc.  
  - Merge child states for nested imports  
  - Enforce immutability if needed, or track changes  

• Example:  
  "TextDirectiveHandler" -> stateService.setTextVar(name, value)  
  "DataDirectiveHandler" -> stateService.setDataVar(name, object)  

─────────────────────────────────────────────────────────────────────────
  5. ValidationService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Validate directive arguments match Meld grammar constraints  
    (E.g. “@text identifier = "string"” must have ‘identifier’ and a string)  
  - Provide standardized error messages  
  - Possibly integrate advanced logic (fuzzy thresholds, etc.)  

• Example:  
  "TextDirectiveHandler" calls validationService.validateTextDirective(directive),  
  throwing MeldError if directive is malformed.  

─────────────────────────────────────────────────────────────────────────
  6. InterpolationService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Expand or replace “${var}”, “#{data.field}”, path variables, etc.  
  - Provide a clean API for directive logic to get fully-resolved strings  
  - Possibly handle multi-step expansions (nested expansions)  

• Example:  
  "PathDirectiveHandler" -> interpolationService.resolveAll("$PROJECTPATH/${subdir}/file")  
  -> final path string  

─────────────────────────────────────────────────────────────────────────
  7. DirectiveService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Own a registry of all directive handlers  
  - Route inbound “DirectiveNode” to the correct handler (Text, Data, Import, etc.)  
  - Each handler is purely business logic for that directive  

• Example Flow:
   A. The Interpreter sees a DirectiveNode with kind="text"  
   B. Calls directiveService.handleDirective(node, stateContext)  
   C. directiveService looks up “TextDirectiveHandler,” calls .execute(node, stateContext)  
   D. That handler uses ValidationService + PathService + StateService, etc.  

Still each directive is easy to test in isolation:  
   const handler = new TextDirectiveHandler(...services)  
   handler.execute(directiveNode, newState)  

─────────────────────────────────────────────────────────────────────────
  8. ParserService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Parse Meld content → AST (MeldNode[])  
  - Possibly use a known parser library or a custom grammar  
  - Provide error location details  

─────────────────────────────────────────────────────────────────────────
  9. InterpreterService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Orchestrates the main “interpretation” pipeline:  
     1) For each AST node:  
         - If Directive, route to DirectiveService  
         - If Text, store as raw text or pass along  
     2) Merge results into StateService  
  - Provide top-level interpretMeld() function  

─────────────────────────────────────────────────────────────────────────
  10. OutputService
─────────────────────────────────────────────────────────────────────────
• Responsibility:  
  - Convert final Meld AST/state to desired format  
    (e.g. Markdown, LLM XML, JSON, etc.)  
  - Possibly wrap code fences, transform directives to <directive> tags, etc.  

─────────────────────────────────────────────────────────────────────────
  ARCHITECTURE RELATIONS (ASCII DIAGRAM)
─────────────────────────────────────────────────────────────────────────

                     +-------------------------+  (1) Get Meld input
                     |      ParserService     |   parse content -> AST
                     +----------+-------------+
                                |
  (2) For each node   +---------v----------+  (2a) If directive:
                     |  InterpreterService | -----> +---------------------+
                     +---------+----------+         | DirectiveService    |
                               |                    |   (registry of      |
                               |                    |   directiveHandlers)|
                     (2b) Node type?                +-------+------------+
                               |                            |
                    +----------v-------------+ (calls out)   |
                    |        StateService    | <------------+
                    +------------------------+
                               |
                               v
       +------------------------------------------------+
       | OutputService or final usage of the State/AST  |
       +------------------------------------------------+

─────────────────────────────────────────────────────────────────────────
  ILLUSTRATION OF A DIRECTIVE’S FLOW (example: @text)
─────────────────────────────────────────────────────────────────────────

   1) ParserService sees line "@text greeting = 'Hello, world!'"
      -> Creates a DirectiveNode { kind: 'text', ... }

   2) InterpreterService processes that node:
      -> directiveService.handleDirective(node, interpreterContext)

   3) directiveService finds "TextDirectiveHandler" in internal registry
      -> textHandler.execute(node, stateService, { interpolationService, validationService, ... })

   4) TextDirectiveHandler:
      A) validationService.validateTextDirective(...)
      B) interpolationService.resolveAll(directive.value)  // if needed
      C) stateService.setTextVar(name, finalValue)

   5) Interpretation continues with next node

─────────────────────────────────────────────────────────────────────────
  EXAMPLE: HANDLER SCAFFOLD
─────────────────────────────────────────────────────────────────────────

export class TextDirectiveHandler {
  constructor(
    private validationService: ValidationService,
    private interpolationService: InterpolationService,
    private stateService: StateService
  ) {}

  public execute(node: DirectiveNode): void {
    // 1) Validate
    this.validationService.validateTextDirective(node);

    // 2) Extract name/value
    const { name, value } = node.directive;

    // 3) Possibly do interpolation
    const resolvedValue = this.interpolationService.resolveAll(value);

    // 4) Store in state
    this.stateService.setTextVar(name, resolvedValue);
  }
}

─────────────────────────────────────────────────────────────────────────
  ADVANTAGES OF THIS DESIGN
─────────────────────────────────────────────────────────────────────────

• Each directive’s logic is short & clean—just orchestrating the relevant services.  
• Path expansions, filesystem I/O, and state merges are decoupled from directives.  
• Clear single responsibility: each service does exactly “one thing.”  
• Tests become simpler: each service is tested with mocks of its dependencies.  
• Better layering: the final pipeline is easy to see in InterpreterService.  

─────────────────────────────────────────────────────────────────────────
  SUB-TASKS TO FLESH OUT THIS DESIGN
─────────────────────────────────────────────────────────────────────────

1. Create Detailed Interface Contracts  
   - Precisely define the method signatures for PathService, FileSystemService, StateService, etc.  
   - Example:  
       interface IPathService {
         resolve(specialPath: string): Promise<string>;
         // ...
       }  

2. Establish Directory & File Structure  
   - Create the new folder layout described above  
   - For each subservice, add a minimal TypeScript file + test placeholder  
   - Example: services/StateService/StateService.ts  

3. Build Common Error Classes in “core/errors”  
   - MeldParseError, MeldDirectiveError, MeldImportError, etc.  
   - Build an ErrorFactory so that we create typed errors with location info  

4. Implement ParserService  
   - Decide whether to hand-roll or adapt a library  
   - Return AST with accurate location data for each node  

5. Implement PathService & FileSystemService  
   - Provide full test coverage with real and mocked file ops  
   - Address expansions for $PROJECTPATH, $HOMEPATH, etc.  

6. Draft All Directive Handlers  
   - @text, @data, @define, @path, @embed, @import, etc.  
   - Each references the relevant services (ValidationService, etc.)  
   - Provide minimal “happy path” logic first  

7. Implement CircularityService  
   - Keep a record (set or map) of imports being processed  
   - If we import the same file in a chain, throw an error  

8. Implement StateService  
   - Clear APIs for setTextVar, getTextVar, setDataVar, etc.  
   - Possibly handle merges for sub-states (like a child file import)  
   - Decide immutability approach  

9. Implement InterpolationService  
   - Expand “${var}” => from text variables  
   - Expand advanced data references “#{config.key}” => from data variables  
   - Provide a single “resolveAll” method for directive handlers  

10. Add Integration Tests  
   - Example: parse + interpret + embed + import across multiple files  
   - Confirm the entire pipeline works end-to-end  

11. Create an OutputService (optional for now)  
   - Provide “toMarkdown,” “toLLM,” etc.  
   - Provide a single “formatOutput(astOrState, options)” method  

12. Document and Polish  
   - Document each service  
   - Provide README for how they connect  
   - Clarify environment variable usage (like test mode, etc.)  

─────────────────────────────────────────────────────────────────────────
  CONCLUSION & NEXT STEPS
─────────────────────────────────────────────────────────────────────────

With this services-based design:

• We strictly adhere to Meld’s grammar and the spec.  
• Each directive is minimal and delegates to the relevant services.  
• We isolate complexity (filesystem, path expansions, state merges, circular checks) so each part is unit-testable.  
• We can proceed incrementally: implement the parser, then each directive, while controlling complexity.  
• In subsequent passes, we can refine performance or advanced features (like fuzzy matching, or advanced @embed logic).  

This architecture will yield a codebase that is both straightforward to grasp and straightforward to extend. Each step is spelled out in the sub-tasks above, allowing incremental development and rigorous testing.  

Ultimately, we achieve a modular, SOLID codebase that we’ll be proud to maintain and expand.
